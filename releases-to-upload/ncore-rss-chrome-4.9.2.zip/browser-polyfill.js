/**
 * browser-polyfill.js - Normalizes Chrome and Firefox extension APIs to browser.*
 */
if (typeof globalThis.browser === "undefined") {
  globalThis.browser = globalThis.chrome;
}
