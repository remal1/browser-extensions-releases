/**
 * rss.js - Main Application Controller, Keyboard Navigation & Bootstrap
 */

function checkScrollToNew() {
  if (!currentSettings?.scrollToNew) return;

  const attemptScroll = (retryCount = 0) => {
    const listContainer = document.querySelector("#torrent-list");
    if (!listContainer) return;

    const newIndicators = listContainer.querySelectorAll('.list-item-indicator.is-new');
    if (!newIndicators.length) {
      if (retryCount < 4) {
        setTimeout(() => attemptScroll(retryCount + 1), 100);
      }
      return;
    }

    // In a descending list (default), the oldest new item is at the bottom of the new block,
    // which represents where the user left off reading previously. Even if all items are new,
    // scroll to the oldest new item so the user does not have to scroll down manually.
    const targetIndicator = (sortState.val.field === 'date' && !sortState.val.asc)
      ? newIndicators[newIndicators.length - 1]
      : newIndicators[0];

    const targetItem = targetIndicator?.closest('.list-item');
    if (targetItem) {
      const containerRect = listContainer.getBoundingClientRect();
      const itemRect = targetItem.getBoundingClientRect();
      const relativeTop = itemRect.top - containerRect.top + listContainer.scrollTop;

      listContainer.scrollTo({
        top: Math.max(0, relativeTop - (containerRect.height / 2) + (itemRect.height / 2)),
        behavior: 'smooth'
      });
    }
  };

  setTimeout(() => attemptScroll(0), 150);
}

function initKeyboardNav() {
  window.addEventListener("keydown", (e) => {
    const searchInput = document.getElementById("torr-search");
    const isSearching = document.activeElement === searchInput;

    if (e.key === "/" && !isSearching) {
      e.preventDefault();
      searchInput?.focus();
      searchInput?.select();
      return;
    }

    if ((e.key === "?" || e.key === "F1") && !isSearching) {
      e.preventDefault();
      openHelpModal();
      return;
    }

    if (e.key === "Escape") {
      if (isSearching) {
        searchInput.value = "";
        applyFilters(currentFilters, null);
        searchInput.blur();
      }
      focusedIndex.val = -1;
      return;
    }

    if (e.key === "Enter" && isSearching) {
      e.preventDefault();
      executeApiSearch(searchInput.value, 1);
      return;
    }

    const listElements = document.querySelectorAll(".list-item");
    if (!listElements.length) return;

    const listContainer = document.querySelector("#torrent-list");

    if (e.key === "Home" && !isSearching) {
      e.preventDefault();
      focusedIndex.val = 0;
      listContainer?.scrollTo({ top: 0, behavior: "smooth" });
      return;
    } else if (e.key === "End" && !isSearching) {
      e.preventDefault();
      focusedIndex.val = listElements.length - 1;
      listContainer?.scrollTo({ top: listContainer.scrollHeight, behavior: "smooth" });
      return;
    } else if (e.key === "PageDown" && !isSearching) {
      e.preventDefault();
      focusedIndex.val = Math.min((focusedIndex.val < 0 ? 0 : focusedIndex.val) + 6, listElements.length - 1);
      listElements[focusedIndex.val]?.scrollIntoView({ block: "nearest", behavior: "smooth" });
      return;
    } else if (e.key === "PageUp" && !isSearching) {
      e.preventDefault();
      focusedIndex.val = Math.max((focusedIndex.val < 0 ? 0 : focusedIndex.val) - 6, 0);
      listElements[focusedIndex.val]?.scrollIntoView({ block: "nearest", behavior: "smooth" });
      return;
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      focusedIndex.val = Math.min(focusedIndex.val + 1, listElements.length - 1);
      listElements[focusedIndex.val]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      focusedIndex.val = Math.max(focusedIndex.val - 1, 0);
      listElements[focusedIndex.val]?.scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter" && focusedIndex.val >= 0) {
      e.preventDefault();
      const targetItem = items[focusedIndex.val];
      if (targetItem) {
        handleTorrentClick(e, targetItem.link);
      }
    } else if (e.key === " " && !isSearching && focusedIndex.val >= 0) {
      e.preventDefault();
      const targetItem = items[focusedIndex.val];
      if (targetItem) {
        toggleAccordion(e, targetItem);
      }
    } else if ((e.key === "d" || e.key === "D") && !isSearching && focusedIndex.val >= 0) {
      e.preventDefault();
      const targetItem = items[focusedIndex.val];
      if (targetItem) {
        handleDownload(e, targetItem);
      }
    } else if ((e.key === "b" || e.key === "B") && !isSearching && focusedIndex.val >= 0) {
      e.preventDefault();
      const targetItem = items[focusedIndex.val];
      if (targetItem) {
        toggleBookmark(e, targetItem);
      }
    } else if ((e.key === "c" || e.key === "C") && !isSearching && focusedIndex.val >= 0) {
      e.preventDefault();
      const targetItem = items[focusedIndex.val];
      if (targetItem) {
        handleCopy(e, targetItem);
      }
    }
  });
}

function handleStorageChange(changes, areaName) {
  if (areaName && areaName !== 'local') return;

  if (changes.lastUpdated && changes.lastUpdated.newValue) {
    const lu = changes.lastUpdated.newValue;
    lastUpdated.val = typeof lu === 'number' ? lu : new Date(lu).getTime();
  }

  if (changes.torrentList && Array.isArray(changes.torrentList.newValue) && changes.torrentList.newValue.length) {
    torrentCache = enrichTorrents(Array.from(changes.torrentList.newValue));
    isCached.val = false;
    applyFilters(currentFilters, document.getElementById("torr-search")?.value);
  }

  if (changes.bookmarks && Array.isArray(changes.bookmarks.newValue)) {
    bookmarks.val = changes.bookmarks.newValue;
  }

  if (changes.visited && Array.isArray(changes.visited.newValue)) {
    visited = changes.visited.newValue;
    applyFilters(currentFilters, document.getElementById("torr-search")?.value);
  }

  if (changes.updateInfo && changes.updateInfo.newValue) {
    updateInfo.val = changes.updateInfo.newValue;
  }

  if (changes.filters && changes.filters.newValue) {
    currentFilters = changes.filters.newValue;
    applyFilters(currentFilters, document.getElementById("torr-search")?.value);
  }
}

function initStorageListener() {
  const storage = (typeof browser !== "undefined" && browser.storage) ? browser.storage : (typeof chrome !== "undefined" ? chrome.storage : null);
  if (!storage || !storage.onChanged) return;
  if (typeof storage.onChanged.hasListener === 'function') {
    if (!storage.onChanged.hasListener(handleStorageChange)) {
      storage.onChanged.addListener(handleStorageChange);
    }
  } else {
    storage.onChanged.addListener(handleStorageChange);
  }
}

async function setup() {
  try {
    savedData = await load(["visited", "lastOpened", "lastUpdated", "filters", "settings", "lastOpenedId", "torrentList", "bookmarks", "updateInfo"]);
    visited = savedData?.visited;
    if (!visited || !Object.keys(visited).length) visited = [];
    if (savedData?.lastOpened) lastOpened.val = savedData.lastOpened;
    if (savedData?.lastOpenedId) lastOpenedId.val = savedData.lastOpenedId;
    if (savedData?.lastUpdated) {
      lastUpdated.val = typeof savedData.lastUpdated === "number"
        ? savedData.lastUpdated
        : new Date(savedData.lastUpdated).getTime();
    }
    if (savedData?.filters) currentFilters = savedData.filters;
    if (Array.isArray(savedData?.bookmarks)) bookmarks.val = savedData.bookmarks;
    if (savedData?.updateInfo) updateInfo.val = savedData.updateInfo;
    if (savedData?.torrentHashes && typeof savedData.torrentHashes === 'object') {
      torrentHashes = savedData.torrentHashes;
    }

    savedData.settings = savedData?.settings || {};
    if (!savedData.settings.dataSource) {
      savedData.settings.dataSource = 'apiv1';
    }
    if (!savedData.settings.client) {
      savedData.settings.client = { type: 'browser' };
    }
    if (!savedData.settings.displayMode) {
      savedData.settings.displayMode = 'popup';
    }
    currentSettings = vanX.reactive(savedData.settings);

    // Sidebar view detection
    const urlParams = new URLSearchParams(window.location.search);
    const isSidebarView = urlParams.get('view') === 'sidebar' || (window.innerWidth < 750 && window.innerHeight > 620);
    if (isSidebarView) {
      document.documentElement.classList.add('is-sidebar');
      document.body.classList.add('is-sidebar');
    } else if (savedData?.settings?.displayMode === 'popup') {
      // Ensure any lingering sidebar is closed when opening popup
      try {
        const sidePanel = globalThis['chrome'] ? globalThis['chrome']['side' + 'Panel'] : null;
        if (sidePanel && typeof sidePanel['close'] === 'function') {
          browser.windows?.getCurrent().then(win => {
            if (win?.id) sidePanel['close']({ windowId: win.id }).catch(() => {});
          }).catch(() => {});
        }
        if (typeof browser !== "undefined" && browser.sidebarAction && typeof browser.sidebarAction.close === 'function') {
          browser.sidebarAction.close().catch(() => {});
        }
      } catch (_) {}
    }

    // Apply theme
    if (currentSettings?.theme === "light") {
      document.documentElement.setAttribute("data-theme", "light");
    } else if (currentSettings?.theme === "dark") {
      document.documentElement.setAttribute("data-theme", "dark");
    } else {
      document.documentElement.removeAttribute("data-theme");
    }

    // Cache resilience: render existing cached list immediately if available
    if (savedData?.torrentList && Array.isArray(savedData.torrentList) && savedData.torrentList.length) {
      torrentCache = enrichTorrents(Array.from(savedData.torrentList));
      isCached.val = true;
    }

    // Check host permissions for Firefox
    try {
      const hasPerm = await browser.permissions.contains({
        origins: ["*://ncore.pro/*", "*://*.ncore.pro/*"]
      });
      needsPermission.val = !hasPerm;
    } catch (_) {
      needsPermission.val = false;
    }

    initList();
    addHeader();
    addControls();
    initKeyboardNav();
    initStorageListener();
    startClientPolling();
    window.addEventListener("pagehide", () => {
      stopClientPolling();
      try {
        const storage = (typeof browser !== "undefined" && browser.storage) ? browser.storage : (typeof chrome !== "undefined" ? chrome.storage : null);
        if (storage?.onChanged && typeof storage.onChanged.removeListener === "function") {
          storage.onChanged.removeListener(handleStorageChange);
        }
      } catch (_) {}
    });

    if (torrentCache && torrentCache.length) {
      applyFilters(currentFilters);
      checkScrollToNew();
    }

    await updateTorrentsList();
    
    let maxId = 0;
    if (torrentCache && torrentCache.length) {
      maxId = torrentCache.reduce((max, t) => ((t.id || 0) > max ? (t.id || 0) : max), 0);
    }
    save({ lastOpened: Date.now(), lastOpenedId: maxId });

    if (browser.action?.setBadgeBackgroundColor) {
      browser.action.setBadgeBackgroundColor({ color: [14, 165, 233, 255] });
    }
    if (browser.action?.setBadgeTextColor) {
      browser.action.setBadgeTextColor({ color: "#ffffff" });
    }
    browser.action.setBadgeText({ text: '' });
    browser.action.setTitle({ title: 'NCore RSS torrent listázó' });

    const visitedLength = visited.length;
    if (visited && visited.length && torrentCache && torrentCache.length) {
      visited = visited.filter(item => torrentCache.findIndex(torr => torr.link === item) > -1);
      if (visitedLength !== visited.length) save({ visited });
    }
  } catch (error) {
    console.error(`[NCore RSS listázó] HIBA:`, error);
    showError(error.message || error.toString());
  }
}

setup().catch(error => {
  console.error(`[NCore RSS listázó] HIBA->${error.message}`);
  showError(error.message);
});