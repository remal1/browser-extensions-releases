/**
 * filters.js - Search, Filtering Logic, and Treeselect Category Integration
 */

let opts = {
  unicode: true,
  interSplit: "[^\\p{L}\\d']+",
  intraSplit: "\\p{Ll}\\p{Lu}",
  intraBound: "\\p{L}\\d|\\d\\p{L}|\\p{Ll}\\p{Lu}",
  intraChars: "[\\p{L}\\d']",
  intraContr: "'\\p{L}{1,2}\\b",
};
let uf = new uFuzzy(opts);

const addFilter = () => {
  const domElement = document.getElementById("filters");
  if (!domElement) return;
  const treeselect = new Treeselect({
    parentHtmlContainer: domElement,
    value: savedData?.filters ? savedData.filters : [],
    options: options,
    staticList: true,
    alwaysOpen: true,
    placeholder: "Keresés a kategóriákban...",
  });

  const debouncedFilter = debounce((categoryFilters) => {
    currentFilters = categoryFilters;
    applyFilters(categoryFilters, document.getElementById("torr-search")?.value);
    save({ filters: categoryFilters });
  }, 150);

  treeselect.srcElement.addEventListener('input', (e) => {
    debouncedFilter(e.detail);
  });
};

const debouncedSearch = debounce((query) => {
  applyFilters(currentFilters, query);
}, 150);

function search(evt) {
  debouncedSearch(evt.target.value);
}

function searchClear(_) {
  const currentVal = document.getElementById("torr-search");
  if (currentVal && currentVal.value) {
    currentVal.value = "";
    if (searchMode.val === 'api') {
      exitApiSearch();
    } else {
      applyFilters(currentFilters, null);
    }
  }
}

function handleSort(field) {
  if (sortState.val.field === field) {
    sortState.val = { field, asc: !sortState.val.asc };
  } else {
    sortState.val = { field, asc: true };
  }
  
  if (searchMode.val === 'api') {
    executeApiSearch(apiQuery.val, 1);
    return;
  }
  
  if (field === 'name') {
    torrentCache.sort((a, b) => sortState.val.asc ? a.title.localeCompare(b.title) : b.title.localeCompare(a.title));
  } else {
    torrentCache.sort((a, b) => {
      const valA = a.pubDate || a.id || 0;
      const valB = b.pubDate || b.id || 0;
      return sortState.val.asc ? valA - valB : valB - valA;
    });
  }
  
  const currentVal = document.getElementById("torr-search");
  applyFilters(currentFilters, currentVal ? currentVal.value : null);
}

function toggleFilters() {
  filtersEnabled.val = !filtersEnabled.val;
  const currentVal = document.getElementById("torr-search");
  applyFilters(currentFilters, currentVal ? currentVal.value : null);
  showToast(filtersEnabled.val ? "Szűrők engedélyezve" : "Szűrők felfüggesztve / kikapcsolva", "info", 1500);
}

function toggleOnlyNew() {
  onlyNewFilter.val = !onlyNewFilter.val;
  if (onlyNewFilter.val) {
    onlyBookmarksFilter.val = false;
  }
  const currentVal = document.getElementById("torr-search");
  applyFilters(currentFilters, currentVal ? currentVal.value : null);
  showToast(onlyNewFilter.val ? "Csak új torrentek szűrve" : "Összes torrent megjelenítve");
}

function toggleOnlyBookmarks() {
  onlyBookmarksFilter.val = !onlyBookmarksFilter.val;
  if (onlyBookmarksFilter.val) {
    onlyNewFilter.val = false;
  }
  const currentVal = document.getElementById("torr-search");
  applyFilters(currentFilters, currentVal ? currentVal.value : null);
  showToast(onlyBookmarksFilter.val ? "Csak könyvjelzők szűrve" : "Összes torrent megjelenítve");
}

async function markAllAsRead() {
  if (torrentCache && torrentCache.length) {
    const maxId = torrentCache.reduce((max, t) => ((t.id || 0) > max ? (t.id || 0) : max), 0);
    lastOpenedId.val = maxId;
    lastOpened.val = Date.now();
    await save({ lastOpened: lastOpened.val, lastOpenedId: lastOpenedId.val });
    browser.action.setBadgeText({ text: '' });
    const currentVal = document.getElementById("torr-search");
    applyFilters(currentFilters, currentVal ? currentVal.value : null);
    showToast("Minden torrent olvasottnak jelölve!", "success");
  }
}

async function executeApiSearch(query, page = 1) {
  if (!query || !String(query).trim()) {
    exitApiSearch();
    return;
  }
  isApiSearching.val = true;
  searchMode.val = "api";
  apiQuery.val = String(query).trim();
  apiCurrentPage.val = page;
  showToast(`Keresés az nCore-on: "${apiQuery.val}"...`, "info", 1500);
  
  try {
    const sending = await safeSendMessage({
      action: "searchApi",
      options: {
        query: apiQuery.val,
        filters: currentFilters,
        sort: sortState.val.field === 'name' ? 'name' : 'ctime',
        order: sortState.val.asc ? 'ASC' : 'DESC',
        page: page,
        perpage: 50
      }
    });
    
    if (sending?.error) {
      showError(sending.error);
      return;
    }
    
    const res = sending?.response;
    if (!res || !Array.isArray(res.results)) {
      showError("Érvénytelen válasz az nCore API-tól");
      return;
    }
    
    const enriched = enrichTorrents(res.results);
    vanX.replace(items, () => enriched);
    listLength.val = enriched.length;
    apiTotalResults.val = res.totalResults || enriched.length;
    
    if (enriched.length === 0) {
      emptyStateReason.val = { type: "search", query: apiQuery.val };
    } else {
      emptyStateReason.val = { type: "none" };
    }
  } catch (err) {
    showError("Keresési hiba: " + err.message);
  } finally {
    isApiSearching.val = false;
  }
}

function exitApiSearch() {
  searchMode.val = "local";
  apiQuery.val = "";
  apiCurrentPage.val = 1;
  apiTotalResults.val = 0;
  const searchInput = document.getElementById("torr-search");
  applyFilters(currentFilters, searchInput ? searchInput.value : null);
  showToast("Visszatérés a helyi friss listához", "info", 1500);
}

function applyFilters(filters = [], query) {
  if (searchMode.val === 'api') {
    return;
  }
  if (!torrentCache || !torrentCache.length) {
    vanX.replace(items, () => []);
    listLength.val = 0;
    emptyStateReason.val = { type: "no_data" };
    return;
  }
  
  // 1. Kategória szűrés
  let afterCat = [...torrentCache];
  if (filtersEnabled.val && filters && filters.length > 0) {
    afterCat = afterCat.filter((torrent) => {
      const catDef = torrent._catDef || resolveCategory(torrent.cat, torrent.title);
      if (!catDef) return true;
      return filters.includes(catDef.slug) || filters.includes(catDef.mainCat) || (catDef.mainCat === 'ebook' && filters.includes('all_ebook'));
    });
  }

  // 2. Csak új torrentek szűrés
  let afterFilter = afterCat;
  if (onlyNewFilter.val) {
    afterFilter = afterFilter.filter(torr => torr.id > lastOpenedId.val || (torr.pubDate && torr.pubDate > lastOpened.val));
  }

  // 3. Csak könyvjelzők szűrés
  if (onlyBookmarksFilter.val) {
    afterFilter = afterFilter.filter(torr => bookmarks.val.includes(torr.id));
  }

  // 4. Min. Seeder szűrő
  if (filtersEnabled.val && minSeedersFilter.val > 0) {
    afterFilter = afterFilter.filter(torr => (torr.seeders == null || torr.seeders >= minSeedersFilter.val));
  }

  // 5. Min. Méret szűrő (MB)
  if (filtersEnabled.val && minSizeMbFilter.val > 0) {
    const minBytes = minSizeMbFilter.val * 1024 * 1024;
    afterFilter = afterFilter.filter(torr => (torr.size == null || torr.size >= minBytes));
  }

  // 6. Keresőszó szűrés
  const result = textSearch(afterFilter, query);
  vanX.replace(items, () => result);
  listLength.val = result.length;
  focusedIndex.val = -1;

  if (result.length === 0) {
    if (query && query.trim()) {
      emptyStateReason.val = { type: "search", query: query.trim() };
    } else if (onlyBookmarksFilter.val && afterCat.length > 0 && afterFilter.length === 0) {
      emptyStateReason.val = { type: "only_bookmarks" };
    } else if (onlyNewFilter.val && afterCat.length > 0 && afterFilter.length === 0) {
      emptyStateReason.val = { type: "only_new" };
    } else if (filtersEnabled.val && torrentCache.length > 0 && afterFilter.length === 0 && (filters.length > 0 || minSeedersFilter.val > 0 || minSizeMbFilter.val > 0)) {
      emptyStateReason.val = { type: "category_filter" };
    } else {
      emptyStateReason.val = { type: "general" };
    }
  } else {
    emptyStateReason.val = { type: "none" };
  }
}

function textSearch(torrents, query) {
  if (!query) {
    return torrents;
  }
  const tokens = query.trim().split(/\s+/);
  const positiveTokens = tokens.filter(t => !t.startsWith("-"));
  const negativeTokens = tokens.filter(t => t.startsWith("-") && t.length > 1).map(t => t.slice(1).toLowerCase());

  let result = torrents;

  // Negative keyword exclusion
  if (negativeTokens.length > 0) {
    result = result.filter(torr => {
      const lowerTitle = torr.title.toLowerCase();
      return !negativeTokens.some(neg => lowerTitle.includes(neg));
    });
  }

  if (!positiveTokens.length) {
    return result;
  }

  const posQuery = positiveTokens.join(" ");
  const [idxs] = uf.search(result.map(torr => torr.title), posQuery, 0, 1e3);
  if (!idxs) return [];
  const idxSet = new Set(idxs);
  return result.filter((_, idx) => idxSet.has(idx));
}
