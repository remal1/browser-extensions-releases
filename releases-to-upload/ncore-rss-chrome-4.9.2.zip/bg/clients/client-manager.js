/**
 * bg/clients/client-manager.js - Unified manager and dispatcher for torrent clients
 */

function resolveSavePath(clientSettings = {}, category = "", title = "") {
    let finalSavePath = (clientSettings.savepath || '').trim();
    if (clientSettings.useCategoryPaths && clientSettings.categoryPaths && typeof resolveCategory === 'function') {
        const catDef = resolveCategory(category, title);
        if (catDef && catDef.mainCat && clientSettings.categoryPaths[catDef.mainCat]) {
            const specificPath = clientSettings.categoryPaths[catDef.mainCat].trim();
            if (specificPath) {
                finalSavePath = specificPath;
            }
        }
    }
    return finalSavePath;
}

async function sendToTorrentClient(clientSettings = {}, downloadUrl, title = "", category = "") {
    const type = clientSettings?.type || 'browser';
    if (clientSettings && type !== 'browser' && typeof updateClientOrigin === 'function') {
        await updateClientOrigin(clientSettings);
    }

    const finalSavePath = resolveSavePath(clientSettings, category, title);

    if (type === 'browser') {
        try {
            await browser.downloads.download({
                url: downloadUrl,
                filename: (title ? title.replace(/[/\\?%*:|"<>]/g, '_') : 'torrent') + '.torrent',
                saveAs: false
            });
            return { success: true, message: "A .torrent fájl letöltése elindult a böngészőben!" };
        } catch (err) {
            throw Error(`Böngészős letöltés sikertelen: ${err.message}`);
        }
    }

    if (type === 'qbittorrent') {
        return await QBittorrentClient.addTorrent(clientSettings, downloadUrl, title, finalSavePath);
    }

    if (type === 'transmission') {
        return await TransmissionClient.addTorrent(clientSettings, downloadUrl, title, finalSavePath);
    }

    throw Error(`Ismeretlen kliens típus: ${type}`);
}

async function testTorrentClient(clientSettings = {}) {
    const type = clientSettings?.type || 'browser';
    if (type === 'browser') {
        return { success: true, message: "A közvetlen böngészős letöltés készen áll." };
    }
    if (clientSettings && typeof updateClientOrigin === 'function') {
        await updateClientOrigin(clientSettings);
    }

    if (type === 'qbittorrent') {
        return await QBittorrentClient.testConnection(clientSettings);
    }

    if (type === 'transmission') {
        return await TransmissionClient.testConnection(clientSettings);
    }

    throw Error(`Ismeretlen kliens típus: ${type}`);
}

async function getClientTorrents(clientSettings = {}) {
    const type = clientSettings?.type || 'browser';
    if (type === 'browser') return [];
    if (clientSettings && typeof updateClientOrigin === 'function') {
        await updateClientOrigin(clientSettings);
    }

    if (type === 'qbittorrent') {
        return await QBittorrentClient.getTorrents(clientSettings);
    }

    if (type === 'transmission') {
        return await TransmissionClient.getTorrents(clientSettings);
    }

    return [];
}

async function controlTorrentClient(clientSettings = {}, hash, command = 'pause') {
    const type = clientSettings?.type || 'browser';
    if (!hash || type === 'browser') return { success: false };
    if (clientSettings && typeof updateClientOrigin === 'function') {
        await updateClientOrigin(clientSettings);
    }

    if (type === 'qbittorrent') {
        return await QBittorrentClient.controlTorrent(clientSettings, hash, command);
    }

    if (type === 'transmission') {
        return await TransmissionClient.controlTorrent(clientSettings, hash, command);
    }

    return { success: false };
}
