/**
 * bg/clients/transmission.js - Transmission RPC API Client
 */

let cachedTransmissionSessionId = null;

const TransmissionClient = {
    getRpcUrl(settings = {}) {
        const baseUrl = normalizeClientUrl(settings.url, 'http://localhost:9091');
        return baseUrl.endsWith('/transmission/rpc') ? baseUrl : `${baseUrl}/transmission/rpc`;
    },

    async sendRpc(settings = {}, payload, timeoutMs = 8000) {
        const rpcUrl = this.getRpcUrl(settings);
        const headers = {
            ...buildBasicAuthHeader(settings),
            'Content-Type': 'application/json'
        };

        if (cachedTransmissionSessionId) {
            headers['X-Transmission-Session-Id'] = cachedTransmissionSessionId;
        }

        let resp = await fetchWithTimeout(rpcUrl, {
            method: 'POST',
            headers,
            credentials: 'include',
            body: JSON.stringify(payload)
        }, timeoutMs);

        // Transmission CSRF Protection: 409 Conflict provides the session ID
        if (resp.status === 409) {
            const newSessionId = resp.headers.get('X-Transmission-Session-Id');
            if (newSessionId) {
                cachedTransmissionSessionId = newSessionId;
                headers['X-Transmission-Session-Id'] = newSessionId;

                // Retry once with the acquired session ID
                resp = await fetchWithTimeout(rpcUrl, {
                    method: 'POST',
                    headers,
                    credentials: 'include',
                    body: JSON.stringify(payload)
                }, timeoutMs);
            }
        }

        return resp;
    },

    async testConnection(settings = {}) {
        const resp = await this.sendRpc(settings, { method: 'session-get' }, 8000);
        if (!resp.ok) {
            throw Error(`Transmission hiba: HTTP ${resp.status} ${resp.statusText}`);
        }
        const data = await resp.json();
        const ver = data?.arguments?.version || '';
        return {
            success: true,
            message: `Sikeres kapcsolat a Transmission-nel! ${ver ? `(Verzió: ${ver})` : ''}`
        };
    },

    async addTorrent(settings = {}, downloadUrl, title = "", finalSavePath = "") {
        const payload = {
            method: 'torrent-add',
            arguments: {
                filename: downloadUrl,
                paused: settings.startImmediately !== true
            }
        };

        if (finalSavePath) {
            payload.arguments['download-dir'] = finalSavePath;
        }
        if (settings.category && settings.category.trim()) {
            payload.arguments.labels = [settings.category.trim()];
        }

        const resp = await this.sendRpc(settings, payload, 10000);
        if (!resp.ok) {
            throw Error(`Transmission hiba: HTTP ${resp.status} ${resp.statusText}`);
        }

        const addJson = await resp.json();
        if (addJson.result !== 'success') {
            throw Error(`Transmission hiba: ${addJson.result}`);
        }

        const addedInfo = addJson.arguments?.['torrent-added'] || addJson.arguments?.['torrent-duplicate'];
        const hash = addedInfo?.hashString || null;
        return {
            success: true,
            message: "Torrent sikeresen hozzáadva a Transmission klienshez!",
            hash
        };
    },

    async getTorrents(settings = {}) {
        const payload = {
            method: 'torrent-get',
            arguments: {
                fields: ["id", "name", "hashString", "percentDone", "status", "rateDownload", "rateUpload", "eta", "totalSize"]
            }
        };

        const resp = await this.sendRpc(settings, payload, 5000);
        if (!resp.ok) {
            throw Error(`Transmission hiba: HTTP ${resp.status}`);
        }

        const getJson = await resp.json();
        if (getJson.result !== 'success') {
            throw Error(`Transmission hiba: ${getJson.result}`);
        }

        const torrents = getJson.arguments?.torrents || [];
        return torrents.map(t => {
            let state = 'downloading';
            if (t.status === 0) {
                state = t.percentDone >= 1 ? 'pausedUP' : 'pausedDL';
            } else if (t.status === 6 || t.status === 5 || t.percentDone >= 1) {
                state = 'uploading';
            } else if (t.status === 4 || t.status === 3) {
                state = 'downloading';
            }

            return {
                hash: t.hashString,
                name: t.name,
                progress: typeof t.percentDone === 'number' ? t.percentDone : 0,
                state,
                dlspeed: t.rateDownload || 0,
                upspeed: t.rateUpload || 0,
                eta: t.eta || 0,
                size: t.totalSize || 0
            };
        });
    },

    async controlTorrent(settings = {}, hash, command = 'pause') {
        if (!hash) return { success: false };
        const method = command === 'resume' ? 'torrent-start' : 'torrent-stop';
        const resp = await this.sendRpc(settings, {
            method,
            arguments: { ids: [hash] }
        }, 5000);

        if (!resp.ok) return { success: false };
        const ctrlJson = await resp.json();
        return { success: ctrlJson.result === 'success' };
    }
};
