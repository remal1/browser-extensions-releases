/**
 * bg/clients/qbittorrent.js - qBittorrent WebUI REST API Client
 */

const QBittorrentClient = {
    getBaseUrl(settings = {}) {
        return normalizeClientUrl(settings.url, 'http://localhost:8080');
    },

    getHeaders(settings = {}, isJson = false) {
        const baseUrl = this.getBaseUrl(settings);
        const headers = {
            ...buildBasicAuthHeader(settings),
            'Referer': baseUrl + '/'
        };
        if (isJson) {
            headers['Content-Type'] = 'application/json';
        }
        return headers;
    },

    async login(baseUrl, settings = {}, timeoutMs = 8000) {
        if (!settings.username && !settings.password) return true;

        const loginUrl = `${baseUrl}/api/v2/auth/login`;
        const loginParams = new URLSearchParams();
        loginParams.append('username', settings.username || '');
        loginParams.append('password', settings.password || '');

        const loginResp = await fetchWithTimeout(loginUrl, {
            method: 'POST',
            headers: {
                ...buildBasicAuthHeader(settings),
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                'Referer': baseUrl + '/'
            },
            credentials: 'include',
            body: loginParams
        }, timeoutMs);

        const loginText = await loginResp.text();
        if (!loginResp.ok) {
            throw Error(`qBittorrent bejelentkezési hiba: HTTP ${loginResp.status} ${loginResp.statusText} (${loginText})`);
        }
        if (loginText.trim() === 'Fails.') {
            throw Error("qBittorrent bejelentkezési hiba: Érvénytelen WebUI felhasználónév vagy jelszó!");
        }
        return true;
    },

    async testConnection(settings = {}) {
        const baseUrl = this.getBaseUrl(settings);
        const authHeaders = buildBasicAuthHeader(settings);

        if (settings.username || settings.password) {
            await this.login(baseUrl, settings, 8000);
        }

        const versionResp = await fetchWithTimeout(`${baseUrl}/api/v2/app/version`, {
            method: 'GET',
            headers: {
                ...authHeaders,
                'Referer': baseUrl + '/'
            },
            credentials: 'include'
        }, 8000);

        if (!versionResp.ok) {
            throw Error(`HTTP ${versionResp.status} ${versionResp.statusText}`);
        }
        const ver = await versionResp.text();
        return { success: true, message: `Sikeres kapcsolat a qBittorrent-tel! (Verzió: ${ver.trim()})` };
    },

    async addTorrent(settings = {}, downloadUrl, title = "", finalSavePath = "") {
        const baseUrl = this.getBaseUrl(settings);
        const authHeaders = buildBasicAuthHeader(settings);

        if (settings.username || settings.password) {
            await this.login(baseUrl, settings, 8000).catch(() => {});
        }

        const addUrl = `${baseUrl}/api/v2/torrents/add`;
        const formData = new FormData();
        formData.append('urls', downloadUrl);
        if (settings.category && settings.category.trim()) {
            formData.append('category', settings.category.trim());
        }
        if (finalSavePath) {
            formData.append('savepath', finalSavePath);
            formData.append('autoTMM', 'false');
        }

        const isPaused = settings.startImmediately !== true;
        formData.append('paused', isPaused ? 'true' : 'false');
        formData.append('stopped', isPaused ? 'true' : 'false');

        const addResp = await fetchWithTimeout(addUrl, {
            method: 'POST',
            headers: {
                ...authHeaders,
                'Referer': baseUrl + '/'
            },
            credentials: 'include',
            body: formData
        }, 10000);

        const addText = await addResp.text();
        if (!addResp.ok) {
            throw Error(`qBittorrent hiba: HTTP ${addResp.status} ${addResp.statusText} (${addText})`);
        }
        if (addText.trim() === 'Fails.') {
            throw Error(`qBittorrent hiba a torrent hozzáadásakor: ${addText}`);
        }

        // Retrieve hash of the newly added torrent
        let addedHash = null;
        try {
            await new Promise(r => setTimeout(r, 400));
            const infoResp = await fetchWithTimeout(`${baseUrl}/api/v2/torrents/info?limit=10&sort=added_on&reverse=true`, {
                headers: {
                    ...authHeaders,
                    'Referer': baseUrl + '/'
                },
                credentials: 'include'
            }, 4000);
            if (infoResp.ok) {
                const list = await infoResp.json();
                const cleanTitle = (title || '').toLowerCase().replace(/[^a-z0-9]/g, '');
                let matched = (list || []).find(t => {
                    const cleanName = (t.name || '').toLowerCase().replace(/\.(mkv|avi|mp4|rar|zip|iso)$/i, '').replace(/[^a-z0-9]/g, '');
                    return cleanTitle && (cleanName === cleanTitle || cleanName.includes(cleanTitle) || cleanTitle.includes(cleanName));
                });
                if (!matched && list && list.length > 0) {
                    matched = list[0];
                }
                if (matched?.hash) {
                    addedHash = matched.hash;
                }
            }
        } catch (e) {
            console.warn("[qBittorrent] Hash lekérdezési figyelmeztetés:", e);
        }

        return {
            success: true,
            message: "Torrent sikeresen hozzáadva a qBittorrent klienshez!",
            hash: addedHash
        };
    },

    async getTorrents(settings = {}) {
        const baseUrl = this.getBaseUrl(settings);
        const authHeaders = buildBasicAuthHeader(settings);
        const infoUrl = `${baseUrl}/api/v2/torrents/info`;

        let resp = await fetchWithTimeout(infoUrl, {
            headers: {
                ...authHeaders,
                'Referer': baseUrl + '/'
            },
            credentials: 'include'
        }, 5000);

        // Smart re-authentication: only perform login if unauthorized
        if ((resp.status === 401 || resp.status === 403) && (settings.username || settings.password)) {
            await this.login(baseUrl, settings, 5000).catch(() => {});
            resp = await fetchWithTimeout(infoUrl, {
                headers: {
                    ...authHeaders,
                    'Referer': baseUrl + '/'
                },
                credentials: 'include'
            }, 5000);
        }

        if (!resp.ok) {
            throw Error(`qBittorrent hiba: HTTP ${resp.status}`);
        }

        const list = await resp.json();
        return (list || []).map(t => ({
            hash: t.hash,
            name: t.name,
            progress: typeof t.progress === 'number' ? t.progress : 0,
            state: t.state,
            dlspeed: t.dlspeed || 0,
            upspeed: t.upspeed || 0,
            eta: t.eta || 0,
            size: t.size || t.total_size || 0
        }));
    },

    async controlTorrent(settings = {}, hash, command = 'pause') {
        if (!hash) return { success: false };
        const baseUrl = this.getBaseUrl(settings);
        const authHeaders = buildBasicAuthHeader(settings);

        const endpoint = command === 'resume' ? '/api/v2/torrents/resume' : '/api/v2/torrents/pause';
        const params = new URLSearchParams();
        params.append('hashes', hash);

        let resp = await fetchWithTimeout(baseUrl + endpoint, {
            method: 'POST',
            headers: {
                ...authHeaders,
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                'Referer': baseUrl + '/'
            },
            credentials: 'include',
            body: params
        }, 5000);

        if (resp.status === 401 || resp.status === 403) {
            await this.login(baseUrl, settings, 5000).catch(() => {});
            resp = await fetchWithTimeout(baseUrl + endpoint, {
                method: 'POST',
                headers: {
                    ...authHeaders,
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                    'Referer': baseUrl + '/'
                },
                credentials: 'include',
                body: params
            }, 5000);
        }

        if (!resp.ok) {
            // Fallback for newer qBittorrent v4.5+ which renamed pause/resume to stop/start
            const fallbackEndpoint = command === 'resume' ? '/api/v2/torrents/start' : '/api/v2/torrents/stop';
            await fetchWithTimeout(baseUrl + fallbackEndpoint, {
                method: 'POST',
                headers: {
                    ...authHeaders,
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                    'Referer': baseUrl + '/'
                },
                credentials: 'include',
                body: params
            }, 5000).catch(() => {});
        }

        return { success: true };
    }
};
