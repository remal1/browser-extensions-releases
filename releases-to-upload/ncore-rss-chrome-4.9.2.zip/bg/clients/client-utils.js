/**
 * bg/clients/client-utils.js - Shared networking & authentication utilities for torrent clients
 */

async function fetchWithTimeout(resource, options = {}, timeoutMs = 10000) {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeoutMs);
    try {
        const response = await fetch(resource, {
            ...options,
            signal: controller.signal
        });
        clearTimeout(id);
        return response;
    } catch (error) {
        clearTimeout(id);
        if (error.name === 'AbortError') {
            throw Error('Hálózati időtúllépés (Timeout): az nCore vagy a kliens nem válaszolt időben.');
        }
        throw error;
    }
}

function normalizeClientUrl(url, defaultUrl) {
    let baseUrl = (url || defaultUrl || '').trim().replace(/\/+$/, '');
    if (!baseUrl.startsWith('http://') && !baseUrl.startsWith('https://')) {
        baseUrl = 'http://' + baseUrl;
    }
    return baseUrl;
}

function buildBasicAuthHeader(settings = {}) {
    if (!settings.useHttpAuth) return {};
    const user = settings.httpUsername || settings.username || '';
    const pass = settings.httpPassword || settings.password || '';
    if (!user && !pass) return {};
    try {
        return { 'Authorization': 'Basic ' + btoa(`${user}:${pass}`) };
    } catch (_) {
        return {};
    }
}
