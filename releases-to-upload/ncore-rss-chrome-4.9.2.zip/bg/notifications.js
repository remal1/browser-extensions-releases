/**
 * bg/notifications.js - Keyword Matching, ReDoS Protection & Desktop Notifications
 */

function isSafeRegexPattern(pattern) {
    if (!pattern || typeof pattern !== 'string') return false;
    if (pattern.length > 200) return false;
    // Detect nested quantifiers prone to catastrophic backtracking (e.g. (a+)+, (.*)+, (\w+)*)
    if (/(\+|\*|\{\d+,?\d*\})\s*(\+|\*|\{\d+,?\d*\})/.test(pattern)) return false;
    if (/\([^)]*(\+|\*|\{\d+,?\d*\})[^)]*\)\s*(\+|\*|\{\d+,?\d*\})/.test(pattern)) return false;
    return true;
}

function matchKeywordRule(rule, title) {
    if (!rule || !title) return false;
    const trimmedRule = rule.trim();
    if (!trimmedRule) return false;

    // 1. Regex mode: /pattern/flags (e.g. /house\.of\.the\.dragon.*2160p/i)
    const regexMatch = trimmedRule.match(/^\/(.+)\/([a-z]*)$/);
    if (regexMatch) {
        const pattern = regexMatch[1];
        const flags = regexMatch[2] || 'i';

        if (!isSafeRegexPattern(pattern)) {
            console.warn("[Értesítés] Potenciálisan veszélyes vagy túl hosszú Regex szabály elutasítva:", trimmedRule);
            return false;
        }

        try {
            const regex = new RegExp(pattern, flags);
            return regex.test(title);
        } catch (err) {
            console.warn("[Értesítés] Érvénytelen Regex szabály:", trimmedRule, err);
            return false;
        }
    }

    // 2. Tokenized multi-term mode (AND + NOT)
    const titleLower = title.toLowerCase();
    // Normalized title replaces common separators with spaces
    const titleNormalized = titleLower.replace(/[\.\_\-\+\:\/\\]+/g, ' ');

    const tokens = trimmedRule.split(/\s+/).filter(Boolean);
    if (!tokens.length) return false;

    const positiveTokens = [];
    const negativeTokens = [];

    for (const token of tokens) {
        if (token.startsWith('-') && token.length > 1) {
            negativeTokens.push(token.slice(1).toLowerCase());
        } else {
            positiveTokens.push(token.toLowerCase());
        }
    }

    // Check negative tokens (NOT): if any negative token matches in either raw or normalized title -> reject
    for (const neg of negativeTokens) {
        if (titleLower.includes(neg) || titleNormalized.includes(neg)) {
            return false;
        }
    }

    // Check positive tokens (AND): all positive tokens must match in either raw or normalized title
    if (positiveTokens.length > 0) {
        for (const pos of positiveTokens) {
            if (!titleLower.includes(pos) && !titleNormalized.includes(pos)) {
                return false;
            }
        }
        return true;
    }

    // If only negative tokens were given (e.g. -cam), and none matched, then it matches
    return negativeTokens.length > 0;
}

async function checkKeywordNotifications(newItems, settings) {
    if (!settings?.enableNotifications || !settings?.keywords || !Array.isArray(newItems) || !newItems.length) {
        return;
    }

    // Parse rules: split by newline first; for non-regex lines, allow comma separation too
    const rawLines = settings.keywords.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const rules = [];

    for (const line of rawLines) {
        if (/^\/.+\/[a-z]*$/.test(line)) {
            rules.push(line);
        } else {
            const parts = line.split(',').map(p => p.trim()).filter(Boolean);
            rules.push(...parts);
        }
    }

    if (!rules.length) return;

    for (const item of newItems) {
        if (!item?.title) continue;
        const matched = rules.some(rule => matchKeywordRule(rule, item.title));
        if (matched) {
            try {
                await browser.notifications.create(`ncore-torrent-${item.id}`, {
                    type: 'basic',
                    iconUrl: 'icons/ncoreX-128.png',
                    title: `nCore találat: [${item.cat || 'Torrent'}]`,
                    message: item.title
                });
            } catch (err) {
                console.error("Értesítés hiba:", err);
            }
        }
    }
}

// Notification click listener
if (typeof browser !== "undefined" && browser.notifications && browser.notifications.onClicked) {
    if (!browser.notifications.onClicked.hasListener(onNotificationClicked)) {
        browser.notifications.onClicked.addListener(onNotificationClicked);
    }
}

function onNotificationClicked(notifId) {
    if (notifId && notifId.startsWith('ncore-torrent-')) {
        const id = notifId.replace('ncore-torrent-', '');
        browser.tabs.create({ url: `https://ncore.pro/torrents.php?action=details&id=${id}` });
        browser.notifications.clear(notifId);
    }
}
