/**
 * bg/ncore.js - nCore Feed Fetching, Live Search & Details Scraper
 */

const rssFeedUrl = "https://ncore.pro/rss.php?key=";

function decodeHtmlEntities(str) {
    if (!str || typeof str !== 'string') return '';
    const entities = {
        '&amp;': '&',
        '&lt;': '<',
        '&gt;': '>',
        '&quot;': '"',
        '&#039;': "'",
        '&apos;': "'",
        '&#39;': "'",
        '&nbsp;': ' '
    };
    return str.replace(/&(?:amp|lt|gt|quot|apos|#0?39|nbsp);/gi, m => entities[m.toLowerCase()] || m);
}

async function updateTorrents(forced = false) {
    try {
        let newTorrents = 0;
        const savedData = await load();
        const settings = savedData?.settings || {};
        const dataSource = settings.dataSource || 'apiv1';
        const refreshInterval = settings.refreshInterval || 15;
        const elapsed = new Date() - savedData?.lastUpdated;
        // Allow a 15-second tolerance for browser alarm timer jitter / clock drift
        const minWaitMs = Math.max(10000, refreshInterval * 60 * 1000 - 15000);
        if (!forced && savedData?.torrentList && savedData.torrentList.length && elapsed < minWaitMs) {
            return { torrentList: savedData.torrentList, lastUpdated: savedData?.lastUpdated };
        }
        console.log(`Adatok frissítése (${dataSource})`, new Date().toLocaleString('hu-HU', { timeZone: 'Europe/Budapest' }));

        const torrentLista = [];
        let newTorrentsList = [];
        let newTorrentsDetailed = [];
        let maxId = savedData?.lastOpenedId || 0;

        if (dataSource === 'rss') {
            const passkey = settings.key ? settings.key.trim() : '';
            if (!passkey) {
                throw Error("RSS módhoz be kell állítani az nCore Passkeyt a Beállításokban (⚙️)!");
            }
            const resp = await fetchWithTimeout(`${rssFeedUrl}${passkey}`);
            if (!resp.ok) {
                throw Error(`RSS lekérés hiba: HTTP ${resp.status} ${resp.statusText}`);
            }
            const respText = await resp.text();
            // Universal RSS XML parser with HTML entity decoding
            const torrentek = [];
            const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
            let match;
            const cleanCdata = (str) => decodeHtmlEntities((str || "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').trim());
            while ((match = itemRegex.exec(respText)) !== null) {
                const itemContent = match[1];
                const descMatch = itemContent.match(/<description>([\s\S]*?)<\/description>/i);
                const catMatch = itemContent.match(/<category>([\s\S]*?)<\/category>/i);
                const pubMatch = itemContent.match(/<pubDate>([\s\S]*?)<\/pubDate>/i);
                const sourceMatch = itemContent.match(/<source[^>]+url=["']([^"']+)["']/i);

                torrentek.push({
                    torrentNev: cleanCdata(descMatch ? descMatch[1] : ""),
                    torrentKat: cleanCdata(catMatch ? catMatch[1] : ""),
                    torrentPub: cleanCdata(pubMatch ? pubMatch[1] : ""),
                    torrentLink: sourceMatch ? sourceMatch[1] : ""
                });
            }
            for (const torrent of torrentek) {
                const { torrentNev, torrentKat, torrentPub, torrentLink } = torrent;
                const parsedDate = torrentPub ? Date.parse(torrentPub) : Date.now();

                let idMatch = torrentLink.match(/id=(\d+)/);
                let id = idMatch ? parseInt(idMatch[1], 10) : 0;

                const torrItem = {
                    id: id,
                    title: torrentNev,
                    link: torrentLink,
                    cat: torrentKat,
                    pubDate: parsedDate,
                    size: null,
                    seeders: null,
                    leechers: null
                };
                torrentLista.push(torrItem);

                if (id > maxId) {
                    newTorrents++;
                    newTorrentsList.push(`[${torrentKat}] ${torrentNev}`);
                    newTorrentsDetailed.push(torrItem);
                }
            }
        } else if (dataSource === 'apiv1') {
            const resp = await fetchWithTimeout(`https://ncore.pro/torrents.php?oldal=1&jsons=true`);
            if (!resp.ok) {
                if (resp.status === 401 || resp.status === 403) {
                    throw Error("APIv1 hiba: Lejárt a munkamenet az nCore-on (nem vagy bejelentkezve). Jelentkezz be a böngészőben!");
                }
                throw Error(`APIv1 lekérés hiba: HTTP ${resp.status} ${resp.statusText}`);
            }
            const text = await resp.text();
            let jsonData;
            try {
                jsonData = JSON.parse(text);
            } catch (e) {
                if (text.includes("login") || text.includes("<!DOCTYPE") || text.includes("<html") || text.trim().startsWith("<")) {
                    throw Error("APIv1 hiba: Lejárt a munkamenet az nCore-on (nem vagy bejelentkezve). Kérlek jelentkezz be az nCore-ra a böngészőben, vagy válts RSS módra!");
                }
                throw Error(`APIv1 hiba: Érvénytelen válasz az nCore-tól (${e.message})`);
            }
            if (jsonData && jsonData.results) {
                for (const torrent of jsonData.results) {
                    const id = parseInt(torrent.torrent_id, 10);
                    const catDef = typeof resolveCategory === 'function' ? resolveCategory(torrent.category, torrent.release_name) : null;
                    const mappedCat = catDef ? catDef.label : ((typeof apiToCat !== 'undefined' && apiToCat[torrent.category]) || torrent.category);
                    const torrItem = {
                        id: id,
                        title: decodeHtmlEntities(torrent.release_name),
                        link: torrent.details_url,
                        cat: mappedCat,
                        pubDate: null,
                        size: torrent.size,
                        seeders: torrent.seeders,
                        leechers: torrent.leechers
                    };
                    torrentLista.push(torrItem);

                    if (id > maxId) {
                        newTorrents++;
                        newTorrentsList.push(`[${mappedCat}] ${torrent.release_name}`);
                        newTorrentsDetailed.push(torrItem);
                    }
                }
            }
        } else if (dataSource === 'apiv2') {
            const resp = await fetchWithTimeout(`https://ncore.pro/api/v2/torrents`);
            if (!resp.ok) {
                if (resp.status === 401 || resp.status === 403) {
                    throw Error("APIv2 hiba: Lejárt a munkamenet az nCore-on (nem vagy bejelentkezve). Jelentkezz be a böngészőben!");
                }
                throw Error(`APIv2 lekérés hiba: HTTP ${resp.status} ${resp.statusText}`);
            }
            const text = await resp.text();
            let jsonData;
            try {
                jsonData = JSON.parse(text);
            } catch (e) {
                if (text.includes("login") || text.includes("<!DOCTYPE") || text.includes("<html") || text.trim().startsWith("<")) {
                    throw Error("APIv2 hiba: Lejárt a munkamenet az nCore-on (nem vagy bejelentkezve). Kérlek jelentkezz be az nCore-ra a böngészőben, vagy válts RSS módra!");
                }
                throw Error(`APIv2 hiba: Érvénytelen válasz az nCore-tól (${e.message})`);
            }
            if (jsonData && jsonData.torrents) {
                for (const torrent of jsonData.torrents) {
                    const id = torrent.id;
                    const catDef = typeof resolveCategory === 'function' ? resolveCategory(torrent.category, torrent.releaseName) : null;
                    const mappedCat = catDef ? catDef.label : ((typeof apiToCat !== 'undefined' && apiToCat[torrent.category]) || torrent.category);
                    const torrItem = {
                        id: id,
                        title: decodeHtmlEntities(torrent.releaseName),
                        link: `https://ncore.pro/torrents.php?action=details&id=${id}`,
                        cat: mappedCat,
                        pubDate: torrent.createdAt ? Date.parse(torrent.createdAt) : null,
                        size: torrent.size,
                        seeders: torrent.seeders,
                        leechers: torrent.leechers
                    };
                    torrentLista.push(torrItem);

                    if (id > maxId) {
                        newTorrents++;
                        newTorrentsList.push(`[${mappedCat}] ${torrent.releaseName}`);
                        newTorrentsDetailed.push(torrItem);
                    }
                }
            }
        }

        // Check desktop notifications for keyword matches
        if (newTorrentsDetailed.length > 0 && typeof checkKeywordNotifications === 'function') {
            checkKeywordNotifications(newTorrentsDetailed, savedData.settings);
        }

        // Save lastUpdated as a numeric timestamp for consistent serialization
        const response = {
            lastUpdated: Date.now()
        };
        if (torrentLista.length) {
            response.torrentList = torrentLista;
            await save(response);
        }

        if (browser.action.setBadgeBackgroundColor) {
            browser.action.setBadgeBackgroundColor({ color: [14, 165, 233, 255] });
        }
        if (browser.action.setBadgeTextColor) {
            browser.action.setBadgeTextColor({ color: "#ffffff" });
        }
        browser.action.setBadgeText({
            text: newTorrents ? newTorrents + '' : ''
        });

        let tooltipText = "NCore RSS torrent listázó";
        if (newTorrentsList.length > 0) {
            tooltipText = newTorrentsList.join('\n');
            if (tooltipText.length > 1000) {
                tooltipText = tooltipText.substring(0, 1000) + "...\n(és továbbiak)";
            }
        }
        browser.action.setTitle({ title: tooltipText });
        console.log("RSS frissítés elkészült");
        return response;
    } catch (error) {
        throw error;
    }
}

async function searchTorrentsApi(options = {}) {
    const { query = "", miben = "name", filters = [], sort = "ctime", order = "DESC", page = 1, perpage = 50 } = options;
    const url = new URL("https://ncore.pro/torrents.php");
    url.searchParams.set("jsons", "true");

    if (query && String(query).trim()) {
        url.searchParams.set("mire", String(query).trim());
        url.searchParams.set("miben", miben || "name");
    }

    if (filters && Array.isArray(filters) && filters.length > 0) {
        const groupSlugMap = {
            movie: 'osszes_film',
            serie: 'osszes_sorozat',
            music: 'osszes_zene',
            xxx: 'osszes_xxx',
            game: 'osszes_jatek',
            app: 'osszes_program',
            ebook: 'osszes_konyv'
        };

        let hasGroup = false;
        for (const cat of filters) {
            if (groupSlugMap[cat]) {
                url.searchParams.append("csoport_listazas", groupSlugMap[cat]);
                hasGroup = true;
            } else {
                url.searchParams.append("kivalasztott_tipus[]", cat);
            }
        }
        if (!hasGroup) {
            url.searchParams.set("tipus", "kivalasztottak_kozott");
        }
    }

    url.searchParams.set("miszerint", sort || "ctime");
    url.searchParams.set("hogyan", order || "DESC");
    url.searchParams.set("oldal", String(page || 1));
    url.searchParams.set("perpage", String(perpage || 50));

    const resp = await fetchWithTimeout(url.toString(), {}, 12000);
    if (!resp.ok) {
        if (resp.status === 401 || resp.status === 403) {
            throw Error("API keresés hiba: Lejárt a munkamenet az nCore-on (nem vagy bejelentkezve). Jelentkezz be a böngészőben!");
        }
        throw Error(`API keresés hiba: HTTP ${resp.status} ${resp.statusText}`);
    }

    const text = await resp.text();
    let jsonData;
    try {
        jsonData = JSON.parse(text);
    } catch (e) {
        if (text.includes("login") || text.includes("<!DOCTYPE") || text.includes("<html") || text.trim().startsWith("<")) {
            throw Error("API keresés hiba: Lejárt a munkamenet az nCore-on. Kérlek jelentkezz be az nCore-ra a böngészőben!");
        }
        throw Error(`API keresés hiba: Érvénytelen válasz (${e.message})`);
    }

    const rawResults = jsonData?.results || [];
    const list = rawResults.map(torrent => {
        const id = parseInt(torrent.torrent_id, 10);
        const catDef = typeof resolveCategory === 'function' ? resolveCategory(torrent.category, torrent.release_name) : null;
        return {
            id,
            title: decodeHtmlEntities(torrent.release_name),
            link: torrent.details_url,
            downloadUrl: torrent.download_url,
            cat: catDef ? catDef.label : ((typeof apiToCat !== 'undefined' && apiToCat[torrent.category]) || torrent.category),
            _catDef: catDef,
            pubDate: null,
            size: torrent.size,
            seeders: torrent.seeders,
            leechers: torrent.leechers,
            freeleech: !!torrent.freeleech,
            imdbId: torrent.imdb_id || null,
            imdbRating: torrent.imdb_rating ? Number(torrent.imdb_rating) : null,
            timesCompleted: torrent.times_completed || null
        };
    });

    return {
        results: list,
        totalResults: jsonData?.total_results || list.length,
        onpage: jsonData?.onpage || list.length,
        perpage: jsonData?.perpage || perpage,
        page: page || 1
    };
}

async function getTorrentDrop(id) {
    if (!id) throw Error("Hiányzó torrent azonosító");
    const detailsUrl = `https://ncore.pro/torrents.php?action=details&id=${id}`;
    const resp = await fetchWithTimeout(detailsUrl, {}, 10000);
    if (!resp.ok) {
        throw Error(`Részletek letöltése sikertelen: HTTP ${resp.status}`);
    }
    const htmlText = await resp.text();

    // 1. Strictly isolate #details1 (release info and description container)
    // Never include #details2 (comments, comment form, thanks table)
    let details1Html = "";
    const d1StartMatch = htmlText.match(/<div[^>]*id=["']details1["'][^>]*>/i);
    if (d1StartMatch) {
        const d1StartIndex = d1StartMatch.index + d1StartMatch[0].length;
        const d2Match = htmlText.indexOf('id="details2"', d1StartIndex);
        if (d2Match !== -1) {
            const d2TagStart = htmlText.lastIndexOf('<div', d2Match);
            details1Html = htmlText.substring(d1StartIndex, d2TagStart !== -1 ? d2TagStart : d2Match);
        } else {
            details1Html = htmlText.substring(d1StartIndex);
        }
    } else {
        const altMatch = htmlText.match(/class=["'][^"']*(?:torrent_reszletek_leiras)[^"']*["'][^>]*>/i);
        if (altMatch) {
            const startIdx = altMatch.index + altMatch[0].length;
            const endIdx = htmlText.indexOf('id="details2"', startIdx);
            details1Html = endIdx !== -1 ? htmlText.substring(startIdx, endIdx) : htmlText.slice(startIdx, startIdx + 8000);
        } else {
            details1Html = htmlText;
        }
    }

    // 2. Parse poster (inforbar_img or cover image)
    let poster = null;
    const coverMatch = details1Html.match(/class=["'][^"']*inforbar_img[^"']*["'][^>]*>[\s\S]*?<img[^>]+src=["']([^"']+)["']/i)
        || details1Html.match(/<img[^>]+alt=["']Borító["'][^>]*src=["']([^"']+)["']/i)
        || details1Html.match(/src=["'](https?:\/\/[^"']*\/covers\/[^"']+)["']/i)
        || htmlText.match(/class=["'][^"']*inforbar_img[^"']*["'][^>]*>[\s\S]*?<img[^>]+src=["']([^"']+)["']/i);
    if (coverMatch) {
        poster = coverMatch[1];
    }

    // 3. Parse screenshots with both fast thumbnail and full resolution URLs
    const screenshots = [];
    const fancyBlockRegex = /<a[^>]+class=["'][^"']*fancy_groups[^"']*["'][^>]*href=["']([^"']+)["'][^>]*>[\s\S]*?<img[^>]+src=["']([^"']+)["'][^>]*>/gi;
    let fancyMatch;
    while ((fancyMatch = fancyBlockRegex.exec(details1Html)) !== null) {
        const full = fancyMatch[1];
        const thumb = fancyMatch[2] || full;
        if (full && !screenshots.some(s => s.full === full) && !full.includes('/covers/')) {
            screenshots.push({ full, thumb });
        }
    }

    // Fallback if no fancy_groups with img was found in details1
    if (screenshots.length === 0) {
        const fancyLinks = details1Html.matchAll(/class=["'][^"']*fancy_groups[^"']*["'][^>]*href=["']([^"']+)["']/gi);
        for (const m of fancyLinks) {
            if (m[1] && !screenshots.some(s => s.full === m[1]) && !m[1].includes('/covers/')) {
                screenshots.push({ full: m[1], thumb: m[1] });
            }
        }
    }
    if (screenshots.length === 0) {
        const imgMatch = details1Html.matchAll(/<img[^>]+src=["'](https?:\/\/[^"']+(?:burst\.sh|images\/)[^"']+)["'][^>]*>/gi);
        for (const m of imgMatch) {
            const src = m[1];
            if (src && !screenshots.some(s => s.full === src) && !src.includes('/covers/')) {
                screenshots.push({ full: src, thumb: src });
            }
        }
    }

    // 4. Parse tags
    const tags = [];
    const tagMatch = details1Html.matchAll(/href=["']torrents\.php\?tags=([^"']+)["'][^>]*>#?([^<]+)<\/a>/gi);
    for (const match of tagMatch) {
        const tagText = match[2].trim();
        if (tagText && !tags.includes(tagText)) {
            tags.push(decodeHtmlEntities(tagText));
        }
    }

    // 5. Extract external links (IMDb, Mafab, Port.hu, TMDb, Steam, YouTube, etc.)
    const externalLinks = [];
    const seenLinks = new Set();
    const seenTypes = new Set();
    const registerExtLink = (type, label, url) => {
        if (!url) return;
        let cleanUrl = url.trim().replace(/[.,;)…]+$/, '');
        // Discard truncated URLs (e.g. ending with dots, ellipses, or incomplete slugs)
        if (/\.{2,}|…/.test(url) || cleanUrl.endsWith('/pa') || cleanUrl.length < 16) {
            return;
        }
        if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
            cleanUrl = 'https://' + cleanUrl;
        }
        const linkKey = `${type}:${cleanUrl.toLowerCase()}`;
        if (!seenLinks.has(linkKey) && !seenLinks.has(cleanUrl)) {
            // For major media/database links, prevent duplicate entries of the same type
            if (['imdb', 'mafab', 'port', 'tmdb'].includes(type) && seenTypes.has(type)) {
                return;
            }
            seenLinks.add(linkKey);
            seenLinks.add(cleanUrl);
            seenTypes.add(type);
            externalLinks.push({ type, label, url: cleanUrl });
        }
    };

    // 5a. Look for external links in <a> tags
    const aRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let aM;
    while ((aM = aRegex.exec(details1Html)) !== null) {
        let href = aM[1];
        // Unwrap anonymizer / redirect links (e.g. none.st/?q=https%3A%2F%2F... or dereferer)
        const anonMatch = href.match(/(?:none\.st\/\?q=|dereferer\.(?:me|org)\/\?|anonym\.to\/\?)(https?[^"'>&]+)/i);
        if (anonMatch) {
            try {
                href = decodeURIComponent(anonMatch[1]);
            } catch (e) {
                href = anonMatch[1];
            }
        }

        if (/imdb\.com\/title\/tt\d+/i.test(href)) {
            registerExtLink('imdb', 'IMDb', href);
        } else if (/mafab\.hu/i.test(href)) {
            registerExtLink('mafab', 'Mafab', href);
        } else if (/port\.hu\/(?:adatlap|film)/i.test(href)) {
            registerExtLink('port', 'Port.hu', href);
        } else if (/themoviedb\.org/i.test(href)) {
            registerExtLink('tmdb', 'TMDb', href);
        } else if (/store\.steampowered\.com\/app\/\d+/i.test(href)) {
            registerExtLink('steam', 'Steam', href);
        } else if (/(?:youtube\.com\/watch|youtu\.be\/)/i.test(href)) {
            registerExtLink('youtube', 'Előzetes', href);
        } else if (/discogs\.com\/(?:release|master)/i.test(href)) {
            registerExtLink('discogs', 'Discogs', href);
        } else if (/myanimelist\.net\/anime\/\d+/i.test(href)) {
            registerExtLink('mal', 'MyAnimeList', href);
        } else if (/anidb\.net\/(?:anime|a)\d+/i.test(href)) {
            registerExtLink('anidb', 'AniDB', href);
        } else if (/animeaddicts\.hu/i.test(href)) {
            registerExtLink('animeaddicts', 'AnimeAddicts', href);
        }
    }

    // 5b. Look for raw plain-text URLs in the description text (excluding text inside <a> tags)
    const textWithoutAnchors = details1Html.replace(/<a\b[^>]*>[\s\S]*?<\/a>/gi, ' ');
    const imdbPlain = textWithoutAnchors.matchAll(/https?:\/\/(?:www\.)?imdb\.com\/title\/tt\d+[^\s"<>']*/gi);
    for (const m of imdbPlain) registerExtLink('imdb', 'IMDb', m[0]);

    const mafabPlain = textWithoutAnchors.matchAll(/https?:\/\/(?:www\.)?mafab\.hu\/[^\s"<>']+/gi);
    for (const m of mafabPlain) registerExtLink('mafab', 'Mafab', m[0]);

    const portPlain = textWithoutAnchors.matchAll(/https?:\/\/(?:www\.)?port\.hu\/(?:adatlap|film)\/[^\s"<>']+/gi);
    for (const m of portPlain) registerExtLink('port', 'Port.hu', m[0]);

    const steamPlain = textWithoutAnchors.matchAll(/https?:\/\/store\.steampowered\.com\/app\/\d+[^\s"<>']*/gi);
    for (const m of steamPlain) registerExtLink('steam', 'Steam', m[0]);

    const ytPlain = textWithoutAnchors.matchAll(/https?:\/\/(?:www\.)?(?:youtube\.com\/watch\?v=[\w-]+|youtu\.be\/[\w-]+)/gi);
    for (const m of ytPlain) registerExtLink('youtube', 'Előzetes', m[0]);

    // 6. Robust description extraction:
    // Take at most the first 2 .torrent_leiras divs strictly from #details1, or inforbar_txt plot summary
    const descParts = [];

    // Extract first 2 .torrent_leiras divs from details1Html with balanced div depth (skipping thanks and comments)
    const torrentLeirasDivs = [];
    const tlRx = /<div[^>]*class=["'][^"']*\btorrent_leiras\b[^"']*["'][^>]*>/gi;
    let tlM;
    while ((tlM = tlRx.exec(details1Html)) !== null && torrentLeirasDivs.length < 2) {
        const openingTag = tlM[0];
        const startIndex = tlM.index + openingTag.length;
        let depth = 1;
        const tagRx = /<\/?div\b[^>]*>/gi;
        tagRx.lastIndex = startIndex;
        let tagMatch;
        let endIndex = details1Html.length;
        while ((tagMatch = tagRx.exec(details1Html)) !== null) {
            if (tagMatch[0].startsWith('</')) {
                depth--;
                if (depth === 0) {
                    endIndex = tagMatch.index;
                    break;
                }
            } else {
                depth++;
            }
        }
        const divContent = details1Html.substring(startIndex, endIndex);
        tlRx.lastIndex = endIndex + 6;

        // Skip thanks section, comments, or image-only fancy gallery containers
        if (openingTag.includes('ncoreKoszonetAjax') ||
            divContent.includes('id="ncoreKoszonetAjax"') ||
            divContent.includes('Akik eddig megköszönték') ||
            divContent.includes('Még nem köszönte meg senki')) {
            continue;
        }
        torrentLeirasDivs.push(divContent);
    }

    // Check for inforbar plot / text if present
    const inforbarTxtMatch = details1Html.match(/<td[^>]*class=["'][^"']*\binforbar_txt\b[^"']*["'][^>]*>([\s\S]*?)<\/td>/i);
    if (inforbarTxtMatch) {
        const infobarRaw = inforbarTxtMatch[1];
        const tartalomMatch = infobarRaw.match(/(?:<b[^>]*>\s*Tartalom:?\s*<\/b>|<span[^>]*>\s*Tartalom:?\s*<\/span>|Tartalom:)([\s\S]*?)(?:<table|<div class="clear|<div class="inforbar_|$)/i);
        if (tartalomMatch) {
            descParts.push(tartalomMatch[1]);
        } else if (torrentLeirasDivs.length === 0) {
            descParts.push(infobarRaw);
        }
    }

    descParts.push(...torrentLeirasDivs);

    let combinedDesc = descParts.join(' ');
    if (!combinedDesc.trim()) {
        combinedDesc = details1Html.slice(0, 2000);
    }

    const cleanedDesc = combinedDesc
        .replace(/<script[\s\S]*?<\/script>/gi, ' ')
        .replace(/<style[\s\S]*?<\/style>/gi, ' ')
        .replace(/<form[\s\S]*?<\/form>/gi, ' ')
        .replace(/<button[\s\S]*?<\/button>/gi, ' ')
        .replace(/<div[^>]*class=["'][^"']*show_resized[^"']*["'][^>]*>[\s\S]*?<\/div>/gi, ' ')
        .replace(/<div[^>]*id=["']ncoreKoszonetAjax["'][^>]*>[\s\S]*?<\/div>/gi, ' ')
        // Remove nCore Spoiler UI widgets (toggle button and "... spoiler ..." placeholder)
        .replace(/<a[^>]+onclick=["'][^"']*Spoiler[^"']*["'][^>]*>[\s\S]*?<\/a>/gi, ' ')
        .replace(/<div[^>]*>\s*\.{2,}\s*spoiler\s*\.{2,}\s*<\/div>/gi, ' ')
        .replace(/(?:\[[^\]]*\]\s*)?Spoiler\s+(?:megjelenítése|elrejtése)/gi, ' ')
        .replace(/\.{2,}\s*spoiler\s*\.{2,}/gi, ' ')
        // Remove Címkék row/block (already shown as tags badges at top)
        .replace(/<b[^>]*>\s*Címkék:?\s*<\/b>[\s\S]*?(?:<br\s*\/?>|<\/td>|<\/div>|<\/p>|<table|<b\b|$)/gi, ' ')
        .replace(/(?:<b[^>]*>\s*Címkék:?\s*<\/b>|<span[^>]*>\s*Címkék:?\s*<\/span>|Címkék:?)[\s\S]*?(?:<br\s*\/?>|<\/td>|<\/div>|<\/p>|<table|<b\b|$)/gi, ' ')
        .replace(/Címkék:?\s*[^,.\n\r]+(?:\s*,\s*[^,.\n\r]+)*/gi, ' ')
        // Remove "Eredeti release!"
        .replace(/Eredeti release!?/gi, ' ')
        // Remove thanks blocks
        .replace(/Akik eddig megköszönték[\s\S]*?(?:Még nem köszönte meg senki!|\d+\s*tag)?/gi, ' ')
        .replace(/Még nem köszönte meg senki!?/gi, ' ')
        .replace(/Torrent letöltése/gi, ' ')
        // Remove comments
        .replace(/Hozzászólások\s*[\s\S]*?(?:Szólj hozzá te is!|$)/gi, ' ')
        .replace(/Ehhez a torrenthez még senki nem írt hozzászólást!?/gi, ' ')
        .replace(/Szólj hozzá te is!?/gi, ' ')
        .replace(/Ez egy átméretezett kép[^\n<.]*\.?/gi, ' ')
        // Remove IMDb / Mafab / Port / Egyéb link rows and text
        .replace(/<b[^>]*>\s*(?:IMDb|Mafab|Port\.hu|Egyéb)\s*link:?\s*<\/b>[\s\S]*?(?:<br\s*\/?>|<\/td>|<\/div>|<\/p>|<table|<b\b|$)/gi, ' ')
        .replace(/(?:IMDb|Mafab|Port\.hu|Egyéb)\s*link:?[^\n\r<]*/gi, ' ')
        .replace(/(?:IMDb|Mafab|Port\.hu|Egyéb)\s*(?:link)?:?\s*https?:\/\/\S+/gi, ' ')
        .replace(/<br\s*\/?>/gi, ' ')
        .replace(/<\/p>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/&nbsp;/gi, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    // Check if the remaining text has real content (excluding standalone URLs or remaining punctuation)
    const textWithoutUrls = cleanedDesc
        .replace(/https?:\/\/\S+/gi, '')
        .replace(/[^a-zA-Z0-9áéíóöőúüűÁÉÍÓÖŐÚÜŰ]/g, '')
        .trim();

    let descSnippet = "";
    if (textWithoutUrls.length >= 10) {
        const textOnly = cleanedDesc.replace(/https?:\/\/\S+/gi, ' ').replace(/\s+/g, ' ').trim();
        descSnippet = decodeHtmlEntities(textOnly);
        // Allow full description to be read via scrollbar without premature truncation
        if (descSnippet.length > 2500) {
            descSnippet = descSnippet.slice(0, 2500).replace(/\s+\S*$/, '') + '...';
        }
    }

    // Helper to extract text from .dt label ... .dd value
    const extractDd = (label) => {
        const rx = new RegExp(`class=["'][^"']*\\bdt\\b[^"']*["'][^>]*>\\s*${label}:?\\s*<\\/div>\\s*<div[^>]*class=["'][^"']*\\bdd\\b[^"']*["'][^>]*>([\\s\\S]*?)<\\/div>`, 'i');
        const m = htmlText.match(rx);
        if (!m) return null;
        const txt = m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
        return decodeHtmlEntities(txt);
    };

    const commentsCount = extractDd('Hozzászólás');
    const filesCount = extractDd('Fájlok');
    const uploadedAt = extractDd('Feltöltve');
    const completedCount = extractDd('Letöltve');

    return {
        id,
        poster,
        screenshots: screenshots.slice(0, 3),
        tags,
        externalLinks,
        descSnippet,
        commentsCount,
        filesCount,
        uploadedAt,
        completedCount
    };
}

