/**
 * bg/network.js - Network Interception & Cross-Origin Header Handling for Torrent Clients
 * 
 * Required because Firefox MV3 strips cross-origin cookies (SameSite restrictions)
 * and strict Origin/Referer headers which qBittorrent heavily relies on for CSRF protection.
 * STRICTLY SCOPED to the user's configured torrent client URL to prevent touching other sites.
 */

const torrentCookies = {};
let configuredClientOrigin = "";
const CLIENT_DNR_RULE_ID = 8801;
let lastRegisteredOrigin = null;
let lastRegisteredReferer = null;

async function updateDeclarativeNetRequestRules(clientOrigin, clientReferer) {
    const referer = clientOrigin ? (clientReferer || (clientOrigin + "/")) : "";

    // Skip re-registration if already active for the exact same origin & referer
    if (clientOrigin === lastRegisteredOrigin && referer === lastRegisteredReferer) {
        return;
    }

    const dnr = (typeof chrome !== "undefined" && chrome.declarativeNetRequest)
        ? chrome.declarativeNetRequest
        : (typeof browser !== "undefined" && browser.declarativeNetRequest ? browser.declarativeNetRequest : null);

    if (!dnr || !dnr.updateDynamicRules) return;

    try {
        if (!clientOrigin) {
            await dnr.updateDynamicRules({ removeRuleIds: [CLIENT_DNR_RULE_ID] });
            lastRegisteredOrigin = "";
            lastRegisteredReferer = "";
            return;
        }

        const referer = clientReferer || (clientOrigin + "/");
        const rule = {
            id: CLIENT_DNR_RULE_ID,
            priority: 1,
            action: {
                type: "modifyHeaders",
                requestHeaders: [
                    { header: "Origin", operation: "set", value: clientOrigin },
                    { header: "Referer", operation: "set", value: referer }
                ]
            },
            condition: {
                urlFilter: clientOrigin + "/*",
                resourceTypes: ["xmlhttprequest", "other"]
            }
        };

        await dnr.updateDynamicRules({
            removeRuleIds: [CLIENT_DNR_RULE_ID],
            addRules: [rule]
        });
        lastRegisteredOrigin = clientOrigin;
        lastRegisteredReferer = referer;
        console.log(`[DNR] Dynamic rule registered for ${clientOrigin} (Referer: ${referer})`);
    } catch (e) {
        console.warn("[DNR] Failed to update dynamic rules:", e);
    }
}

async function updateClientOrigin(clientSettings) {
    if (!clientSettings || clientSettings.type === 'browser') {
        configuredClientOrigin = "";
        await updateDeclarativeNetRequestRules("");
        return;
    }
    const rawUrl = clientSettings.url || (clientSettings.type === 'qbittorrent' ? 'http://localhost:8080' : 'http://localhost:9091');
    let referer = "";
    try {
        let normalized = (rawUrl || '').trim();
        if (!normalized.startsWith('http://') && !normalized.startsWith('https://')) {
            normalized = 'http://' + normalized;
        }
        const parsed = new URL(normalized);
        configuredClientOrigin = parsed.origin;
        const pathname = parsed.pathname && parsed.pathname !== '/' ? parsed.pathname.replace(/\/+$/, '') : '';
        referer = parsed.origin + pathname + '/';
    } catch (e) {
        configuredClientOrigin = "";
    }
    await updateDeclarativeNetRequestRules(configuredClientOrigin, referer);
}

// Firefox MV3 blocking webRequest listeners for cookie/header rewriting
if (typeof browser !== "undefined" && browser.webRequest && browser.webRequest.onHeadersReceived) {
    try {
        browser.webRequest.onHeadersReceived.addListener(
            (details) => {
                if (!configuredClientOrigin || !details.url.startsWith(configuredClientOrigin)) return;
                if (!details.url.includes('/api/v2/') && !details.url.includes('/transmission/rpc')) return;

                let modified = false;
                const url = new URL(details.url);

                const responseHeaders = details.responseHeaders.filter((header) => {
                    if (header.name.toLowerCase() === 'set-cookie') {
                        const match = header.value.match(/^([^;]+)/);
                        if (match) {
                            if (!torrentCookies[url.origin]) torrentCookies[url.origin] = [];
                            const cookieParts = match[1].split('=');
                            const cookieName = cookieParts[0].trim();
                            torrentCookies[url.origin] = torrentCookies[url.origin].filter(c => !c.startsWith(cookieName + '='));
                            torrentCookies[url.origin].push(match[1].trim());
                            modified = true;
                        }
                        return false; // Remove Set-Cookie so browser doesn't drop it due to SameSite
                    }
                    return true;
                });

                if (modified) return { responseHeaders };
            },
            { urls: ["<all_urls>"] },
            ["blocking", "responseHeaders"]
        );
    } catch (e) {
        console.warn("[Network] webRequest.onHeadersReceived registration skipped (e.g. Chrome MV3):", e.message);
    }
}

if (typeof browser !== "undefined" && browser.webRequest && browser.webRequest.onBeforeSendHeaders) {
    try {
        browser.webRequest.onBeforeSendHeaders.addListener(
            (details) => {
                if (!configuredClientOrigin || !details.url.startsWith(configuredClientOrigin)) return;
                if (!details.url.includes('/api/v2/') && !details.url.includes('/transmission/rpc')) return;

                const url = new URL(details.url);

                const requestHeaders = details.requestHeaders.filter((header) => {
                    const name = header.name.toLowerCase();
                    return !['cookie', 'origin', 'referer'].includes(name);
                });

                requestHeaders.push({ name: 'Referer', value: url.origin + '/' });
                requestHeaders.push({ name: 'Origin', value: url.origin });

                if (torrentCookies[url.origin] && torrentCookies[url.origin].length > 0) {
                    requestHeaders.push({ name: 'Cookie', value: torrentCookies[url.origin].join('; ') });
                }

                return { requestHeaders };
            },
            { urls: ["<all_urls>"] },
            ["blocking", "requestHeaders"]
        );
    } catch (e) {
        console.warn("[Network] webRequest.onBeforeSendHeaders registration skipped (e.g. Chrome MV3):", e.message);
    }
}
