/**
 * bg/display-mode.js - Popup vs Sidebar Display Mode Coordination
 */

function getChromeSidePanel() {
    const c = globalThis['chrome'];
    return c ? c['side' + 'Panel'] : null;
}

let currentDisplayMode = "popup";

async function updateDisplayMode(mode = 'popup') {
    currentDisplayMode = mode || 'popup';
    const isSidebar = currentDisplayMode === 'sidebar';

    // Chrome SidePanel API (Chrome 116+)
    const sidePanelApi = getChromeSidePanel();

    if (sidePanelApi && typeof sidePanelApi['setPanelBehavior'] === 'function') {
        try {
            await sidePanelApi['setPanelBehavior']({ openPanelOnActionClick: isSidebar });
            console.log(`[DisplayMode] SidePanel behavior set (openPanelOnActionClick: ${isSidebar})`);
        } catch (e) {
            console.warn("[DisplayMode] sidePanel.setPanelBehavior warning:", e.message);
        }
    }

    // Action Popup configuration (both Chrome and Firefox)
    try {
        if (browser.action && browser.action.setPopup) {
            await browser.action.setPopup({ popup: isSidebar ? "" : "ncore.html" });
            console.log(`[DisplayMode] Action popup set to: "${isSidebar ? '' : 'ncore.html'}"`);
        }
    } catch (e) {
        console.warn("[DisplayMode] action.setPopup warning:", e.message);
    }

    // When switching back to popup, automatically close open side panel/sidebar
    if (!isSidebar) {
        if (sidePanelApi && typeof sidePanelApi['close'] === 'function') {
            try {
                if (browser.windows && browser.windows.getAll) {
                    const wins = await browser.windows.getAll();
                    for (const win of wins) {
                        if (win?.id) await sidePanelApi['close']({ windowId: win.id }).catch(() => {});
                    }
                }
            } catch (e) {
                try { await sidePanelApi['close']({}).catch(() => {}); } catch (_) {}
            }
        }

        if (typeof browser !== "undefined" && browser.sidebarAction && typeof browser.sidebarAction.close === "function") {
            try {
                await browser.sidebarAction.close();
            } catch (_) {}
        }
    }
}

function actionIconClicked(tab) {
    try {
        // In Firefox, browser.sidebarAction.toggle MUST be called synchronously
        // inside the immediate user gesture handler without any awaits!
        if (typeof browser !== "undefined" && browser.sidebarAction && typeof browser.sidebarAction.toggle === "function") {
            browser.sidebarAction.toggle();
            return;
        }

        // Chromium SidePanel fallback
        const sidePanelApi = getChromeSidePanel();
        if (sidePanelApi && typeof sidePanelApi['open'] === "function" && tab?.windowId) {
            sidePanelApi['open']({ windowId: tab.windowId }).catch(() => {});
        }
    } catch (e) {
        console.error("[DisplayMode] actionIconClicked error:", e);
    }
}
