/**
 * bg/update-checker.js - Extension Update Checker & Semver Management for NcoreRSS
 */

const UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/remal1/browser-extensions-releases/main/ncore-rss/version.json";
const UPDATE_ALARM_NAME = "check-extension-updates";
const UPDATE_CHECK_INTERVAL_MINUTES = 1440; // 24 hours

function compareSemver(v1, v2) {
    if (!v1 || !v2) return 0;
    const clean1 = String(v1).replace(/^v/i, '').trim();
    const clean2 = String(v2).replace(/^v/i, '').trim();
    const parts1 = clean1.split('.').map(p => parseInt(p, 10) || 0);
    const parts2 = clean2.split('.').map(p => parseInt(p, 10) || 0);
    const len = Math.max(parts1.length, parts2.length);
    for (let i = 0; i < len; i++) {
        const p1 = parts1[i] || 0;
        const p2 = parts2[i] || 0;
        if (p1 > p2) return 1;
        if (p1 < p2) return -1;
    }
    return 0;
}

async function checkForExtensionUpdates(forced = false) {
    try {
        const currentVersion = browser.runtime.getManifest().version;
        const storage = await browser.storage.local.get(["updateInfo"]);
        const lastInfo = storage?.updateInfo || {};

        // Avoid hammering if not forced (allow max once per hour)
        const ONE_HOUR = 60 * 60 * 1000;
        if (!forced && lastInfo.checkedAt && (Date.now() - lastInfo.checkedAt < ONE_HOUR)) {
            return lastInfo;
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        let response;
        try {
            response = await fetch(`${UPDATE_MANIFEST_URL}?_t=${Date.now()}`, {
                signal: controller.signal,
                cache: 'no-store'
            });
        } finally {
            clearTimeout(timeoutId);
        }

        if (!response.ok) {
            throw new Error(`HTTP ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        const latestVersion = data.version;
        const isNewer = compareSemver(latestVersion, currentVersion) > 0;

        let changelogText = "";
        if (data.changelog) {
            if (typeof data.changelog === "object") {
                changelogText = data.changelog.hu || data.changelog.en || JSON.stringify(data.changelog);
            } else {
                changelogText = String(data.changelog);
            }
        }

        const updatedInfo = {
            hasUpdate: isNewer,
            currentVersion: currentVersion,
            latestVersion: latestVersion || currentVersion,
            releaseDate: data.releaseDate || "",
            changelog: changelogText,
            downloads: data.downloads || {},
            releasePage: data.downloads?.releasePage || "https://github.com/remal1/browser-extensions-releases/releases",
            checkedAt: Date.now()
        };

        await browser.storage.local.set({ updateInfo: updatedInfo });

        // Trigger native update check on Firefox if supported
        if (typeof browser.runtime.requestUpdateCheck === "function") {
            try {
                await browser.runtime.requestUpdateCheck();
            } catch (_) {}
        }

        return updatedInfo;
    } catch (err) {
        console.warn("[UpdateChecker] Check failed:", err.message);
        const fallback = {
            hasUpdate: false,
            currentVersion: browser.runtime.getManifest().version,
            checkedAt: Date.now(),
            error: err.message
        };
        return fallback;
    }
}
