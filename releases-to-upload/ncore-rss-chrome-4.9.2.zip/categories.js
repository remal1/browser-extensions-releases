/**
 * NCore Kategória definíciók, fa struktúra és heurisztikus feloldó motor.
 * Közös modul mind a háttérfolyamat (bg.js), mind a popup felület (rss.js) számára.
 */

var CATEGORY_DEFINITIONS = {
  // Film
  hd_hun: { slug: "hd_hun", label: "Film (HUN HD)", mainCat: "movie", subCat: "hd", lang: "hun", path: "images/ico_hd_hun.gif" },
  hd: { slug: "hd", label: "Film (ENG HD)", mainCat: "movie", subCat: "hd", lang: "eng", path: "images/ico_hd.gif" },
  xvid_hun: { slug: "xvid_hun", label: "Film (HUN SD)", mainCat: "movie", subCat: "sd", lang: "hun", path: "images/ico_xvid_hun.gif" },
  xvid: { slug: "xvid", label: "Film (ENG SD)", mainCat: "movie", subCat: "sd", lang: "eng", path: "images/ico_xvid.gif" },
  dvd_hun: { slug: "dvd_hun", label: "Film (HUN DVD)", mainCat: "movie", subCat: "dvd", lang: "hun", path: "images/ico_dvd_hun.gif" },
  dvd: { slug: "dvd", label: "Film (ENG DVD)", mainCat: "movie", subCat: "dvd", lang: "eng", path: "images/ico_dvd.gif" },
  dvd9_hun: { slug: "dvd9_hun", label: "Film (HUN DVD9)", mainCat: "movie", subCat: "dvd9", lang: "hun", path: "images/ico_dvd9_hun.gif" },
  dvd9: { slug: "dvd9", label: "Film (ENG DVD9)", mainCat: "movie", subCat: "dvd9", lang: "eng", path: "images/ico_dvd9.gif" },
  // Sorozat
  hdser_hun: { slug: "hdser_hun", label: "Sorozat (HUN HD)", mainCat: "serie", subCat: "hd", lang: "hun", path: "images/ico_hdser_hun.gif" },
  hdser: { slug: "hdser", label: "Sorozat (ENG HD)", mainCat: "serie", subCat: "hd", lang: "eng", path: "images/ico_hdser.gif" },
  xvidser_hun: { slug: "xvidser_hun", label: "Sorozat (HUN SD)", mainCat: "serie", subCat: "sd", lang: "hun", path: "images/ico_xvidser_hun.gif" },
  xvidser: { slug: "xvidser", label: "Sorozat (ENG SD)", mainCat: "serie", subCat: "sd", lang: "eng", path: "images/ico_xvidser.gif" },
  dvdser_hun: { slug: "dvdser_hun", label: "Sorozat (HUN DVD)", mainCat: "serie", subCat: "dvd", lang: "hun", path: "images/ico_dvdser_hun.gif" },
  dvdser: { slug: "dvdser", label: "Sorozat (ENG DVD)", mainCat: "serie", subCat: "dvd", lang: "eng", path: "images/ico_dvdser.gif" },
  // Zene
  mp3_hun: { slug: "mp3_hun", label: "Mp3 (HUN)", mainCat: "music", subCat: "mp3", lang: "hun", path: "images/ico_mp3_hun.gif" },
  mp3: { slug: "mp3", label: "Mp3 (ENG)", mainCat: "music", subCat: "mp3", lang: "eng", path: "images/ico_mp3.gif" },
  lossless_hun: { slug: "lossless_hun", label: "Lossless (HUN)", mainCat: "music", subCat: "lossless", lang: "hun", path: "images/ico_lossless_hun.gif" },
  lossless: { slug: "lossless", label: "Lossless (ENG)", mainCat: "music", subCat: "lossless", lang: "eng", path: "images/ico_lossless.gif" },
  clip: { slug: "clip", label: "Klip", mainCat: "music", subCat: "clip", lang: null, path: "images/ico_clip.gif" },
  // XXX
  xxx_hd: { slug: "xxx_hd", label: "XXX (HD)", mainCat: "xxx", subCat: "hd", lang: null, path: "images/ico_xxx_hd.gif" },
  xxx_xvid: { slug: "xxx_xvid", label: "XXX (SD)", mainCat: "xxx", subCat: "sd", lang: null, path: "images/ico_xxx_xvid.gif" },
  xxx_dvd: { slug: "xxx_dvd", label: "XXX (DVD)", mainCat: "xxx", subCat: "dvd", lang: null, path: "images/ico_xxx_dvd.gif" },
  xxx_imageset: { slug: "xxx_imageset", label: "XXX (Imageset)", mainCat: "xxx", subCat: "image", lang: null, path: "images/ico_xxx_imageset.gif" },
  // Játék
  game_iso: { slug: "game_iso", label: "Játék (ISO)", mainCat: "game", subCat: "iso", lang: null, path: "images/ico_game_iso.gif" },
  game_rip: { slug: "game_rip", label: "Játék (RIP)", mainCat: "game", subCat: "rip", lang: null, path: "images/ico_game_rip.gif" },
  console: { slug: "console", label: "Konzol", mainCat: "game", subCat: "console", lang: null, path: "images/ico_console.gif" },
  // Program
  iso: { slug: "iso", label: "Program (ISO)", mainCat: "app", subCat: "iso", lang: null, path: "images/ico_iso.gif" },
  misc: { slug: "misc", label: "Program", mainCat: "app", subCat: "misc", lang: null, path: "images/ico_misc.gif" },
  mobil: { slug: "mobil", label: "Mobil", mainCat: "app", subCat: "mobil", lang: null, path: "images/ico_mobil.gif" },
  // Könyv
  ebook_hun: { slug: "ebook_hun", label: "e-Book (HUN)", mainCat: "ebook", subCat: "ebook", lang: "hun", path: "images/ico_ebook_hun.gif" },
  ebook: { slug: "ebook", label: "e-Book (ENG)", mainCat: "ebook", subCat: "ebook", lang: "eng", path: "images/ico_ebook.gif" }
};

var CATEGORY_BY_SLUG = {};
var CATEGORY_BY_LABEL = {};
for (const [slug, def] of Object.entries(CATEGORY_DEFINITIONS)) {
  CATEGORY_BY_SLUG[slug] = def;
  CATEGORY_BY_LABEL[def.label] = def;
}
var categories = { ...CATEGORY_BY_LABEL, ...CATEGORY_BY_SLUG };

var apiToCat = {
  "lossless": "Lossless (ENG)", "lossless_hun": "Lossless (HUN)",
  "console": "Konzol", "misc": "Program",
  "hdser": "Sorozat (ENG HD)", "hdser_hun": "Sorozat (HUN HD)",
  "hd_hun": "Film (HUN HD)", "hd": "Film (ENG HD)",
  "xxx_imageset": "XXX (Imageset)", "xxx_hd": "XXX (HD)",
  "xxx_xvid": "XXX (SD)", "xxx_dvd": "XXX (DVD)",
  "xvid": "Film (ENG SD)", "xvid_hun": "Film (HUN SD)",
  "xvidser": "Sorozat (ENG SD)", "xvidser_hun": "Sorozat (HUN SD)",
  "dvd": "Film (ENG DVD)", "dvd_hun": "Film (HUN DVD)",
  "dvdser": "Sorozat (ENG DVD)", "dvdser_hun": "Sorozat (HUN DVD)",
  "dvd9": "Film (ENG DVD9)", "dvd9_hun": "Film (HUN DVD9)",
  "game_iso": "Játék (ISO)", "game_rip": "Játék (RIP)",
  "iso": "Program (ISO)", "mp3": "Mp3 (ENG)",
  "mp3_hun": "Mp3 (HUN)", "mobil": "Mobil",
  "ebook": "e-Book (ENG)", "ebook_hun": "e-Book (HUN)",
  "clip": "Klip"
};

var options = [
  {
    name: "Film",
    value: "movie",
    children: [
      { name: "HD (HUN)", value: "hd_hun" },
      { name: "HD (ENG)", value: "hd" },
      { name: "SD (HUN)", value: "xvid_hun" },
      { name: "SD (ENG)", value: "xvid" },
      { name: "DVDR (HUN)", value: "dvd_hun" },
      { name: "DVDR (ENG)", value: "dvd" },
      { name: "DVD9 (HUN)", value: "dvd9_hun" },
      { name: "DVD9 (ENG)", value: "dvd9" }
    ]
  },
  {
    name: "Sorozat",
    value: "serie",
    children: [
      { name: "HD (HUN)", value: "hdser_hun" },
      { name: "HD (ENG)", value: "hdser" },
      { name: "SD (HUN)", value: "xvidser_hun" },
      { name: "SD (ENG)", value: "xvidser" },
      { name: "DVDR (HUN)", value: "dvdser_hun" },
      { name: "DVDR (ENG)", value: "dvdser" }
    ]
  },
  {
    name: "Zene",
    value: "music",
    children: [
      { name: "MP3 (HUN)", value: "mp3_hun" },
      { name: "MP3 (ENG)", value: "mp3" },
      { name: "Lossless (HUN)", value: "lossless_hun" },
      { name: "Lossless (ENG)", value: "lossless" },
      { name: "Klip", value: "clip" }
    ]
  },
  {
    name: "XXX",
    value: "xxx",
    children: [
      { name: "HD", value: "xxx_hd" },
      { name: "SD", value: "xxx_xvid" },
      { name: "DVDR", value: "xxx_dvd" },
      { name: "Imageset", value: "xxx_imageset" }
    ]
  },
  {
    name: "Játék",
    value: "game",
    children: [
      { name: "PC/ISO", value: "game_iso" },
      { name: "PC/RIP", value: "game_rip" },
      { name: "Konzol", value: "console" }
    ]
  },
  {
    name: "Program",
    value: "app",
    children: [
      { name: "Prog/ISO", value: "iso" },
      { name: "Prog/RIP", value: "misc" },
      { name: "Prog/Mobil", value: "mobil" }
    ]
  },
  {
    name: "Könyv",
    value: "all_ebook",
    children: [
      { name: "eBook (HUN)", value: "ebook_hun" },
      { name: "eBook (ENG)", value: "ebook" }
    ]
  }
];

function resolveCategory(cat, title = "") {
  const rawCat = (cat != null ? String(cat).trim() : "");
  if (rawCat && CATEGORY_BY_LABEL[rawCat]) return CATEGORY_BY_LABEL[rawCat];
  if (rawCat && CATEGORY_BY_SLUG[rawCat]) return CATEGORY_BY_SLUG[rawCat];

  let mainHint = null;
  if (rawCat === "1" || /film|movie/i.test(rawCat)) mainHint = "movie";
  else if (rawCat === "2" || /sorozat|serie/i.test(rawCat)) mainHint = "serie";
  else if (rawCat === "3" || /zene|music/i.test(rawCat)) mainHint = "music";
  else if (rawCat === "4" || /j[áa]t[eé]k|game/i.test(rawCat)) mainHint = "game";
  else if (rawCat === "5" || /k[öo]nyv|ebook/i.test(rawCat)) mainHint = "ebook";
  else if (rawCat === "6" || /program|app/i.test(rawCat)) mainHint = "app";
  else if (rawCat === "7" || /xxx/i.test(rawCat)) mainHint = "xxx";

  const t = title || "";
  if (!mainHint) {
    if (/S\d\dE\d\d|S\d\d\b|\bSeason\b|\bEpisode\b/i.test(t)) {
      mainHint = "serie";
    } else if (/\b(flac|alac|lossless|mp3|320kbps)\b/i.test(t)) {
      mainHint = "music";
    } else if (/\b(epub|mobi|pdf|cbr|cbz)\b/i.test(t)) {
      mainHint = "ebook";
    } else if (/\b(iso|repack|codex|skidrow|fitgirl|dodi|switch|ps[345]|xbox)\b/i.test(t)) {
      mainHint = "game";
    } else {
      mainHint = "movie";
    }
  }

  const isHun = /(^|[\.\s\-_])(HUN|HUNDUB|Magyar|Szinkronos|Szinkron|HU)([\.\s\-_]|$)/i.test(t);

  if (mainHint === "movie") {
    if (/dvd9/i.test(t)) return CATEGORY_BY_SLUG[isHun ? "dvd9_hun" : "dvd9"];
    if (/dvdr|dvd-r|\bdvd\b/i.test(t) && !/dvdrip/i.test(t)) return CATEGORY_BY_SLUG[isHun ? "dvd_hun" : "dvd"];
    if (/xvid|dvdrip|bdrip|sd\b/i.test(t) && !/2160p|1080p|720p|bluray|web-dl|webrip/i.test(t)) {
      return CATEGORY_BY_SLUG[isHun ? "xvid_hun" : "xvid"];
    }
    return CATEGORY_BY_SLUG[isHun ? "hd_hun" : "hd"];
  }

  if (mainHint === "serie") {
    if (/dvdr|dvd-r|\bdvd\b/i.test(t) && !/dvdrip/i.test(t)) return CATEGORY_BY_SLUG[isHun ? "dvdser_hun" : "dvdser"];
    if (/xvid|dvdrip|sd\b/i.test(t) && !/2160p|1080p|720p|bluray|web-dl|webrip/i.test(t)) {
      return CATEGORY_BY_SLUG[isHun ? "xvidser_hun" : "xvidser"];
    }
    return CATEGORY_BY_SLUG[isHun ? "hdser_hun" : "hdser"];
  }

  if (mainHint === "music") {
    if (/flac|alac|lossless|wav/i.test(t)) return CATEGORY_BY_SLUG[isHun ? "lossless_hun" : "lossless"];
    if (/clip|video|mkv|mp4/i.test(t)) return CATEGORY_BY_SLUG["clip"];
    return CATEGORY_BY_SLUG[isHun ? "mp3_hun" : "mp3"];
  }

  if (mainHint === "xxx") {
    if (/imageset|image|pack|photo/i.test(t)) return CATEGORY_BY_SLUG["xxx_imageset"];
    if (/dvdr|dvd-r|\bdvd\b/i.test(t)) return CATEGORY_BY_SLUG["xxx_dvd"];
    if (/xvid|sd\b/i.test(t) && !/2160p|1080p|720p|hd/i.test(t)) return CATEGORY_BY_SLUG["xxx_xvid"];
    return CATEGORY_BY_SLUG["xxx_hd"];
  }

  if (mainHint === "game") {
    if (/ps[345]|xbox|switch|nintendo|console/i.test(t)) return CATEGORY_BY_SLUG["console"];
    if (/rip\b/i.test(t)) return CATEGORY_BY_SLUG["game_rip"];
    return CATEGORY_BY_SLUG["game_iso"];
  }

  if (mainHint === "app") {
    if (/android|apk|ios|mobile|mobil/i.test(t)) return CATEGORY_BY_SLUG["mobil"];
    if (/iso\b/i.test(t)) return CATEGORY_BY_SLUG["iso"];
    return CATEGORY_BY_SLUG["misc"];
  }

  if (mainHint === "ebook") {
    return CATEGORY_BY_SLUG[isHun ? "ebook_hun" : "ebook"];
  }

  return CATEGORY_BY_SLUG["hd_hun"];
}
