/**
 * bg.js - Background Service Worker & Entrypoint for NcoreRSS
 * Coordinates modules: network, clients, ncore feed/search, notifications, display modes.
 */

if (typeof globalThis.browser === "undefined") {
    globalThis.browser = globalThis.chrome;
}

// In Chrome MV3 service worker context, synchronously load background submodules
if (typeof importScripts === "function") {
    try {
        importScripts(
            "categories.js",
            "bg/network.js",
            "bg/clients/client-utils.js",
            "bg/clients/qbittorrent.js",
            "bg/clients/transmission.js",
            "bg/clients/client-manager.js",
            "bg/notifications.js",
            "bg/ncore.js",
            "bg/display-mode.js",
            "bg/update-checker.js"
        );
    } catch (e) {
        console.error("[Background] importScripts failed:", e);
    }
}

const alarmName = "ncore-rss-check";

async function createAlarm(periodInMinutes = 1) {
    console.log("createAlarm->periodInMinutes:", periodInMinutes);
    const rssAlarm = await browser.alarms.get(alarmName);
    if (rssAlarm) {
        await browser.alarms.clear(alarmName);
    }
    if (periodInMinutes < 1) return;
    browser.alarms.create(alarmName, { periodInMinutes });
}

async function load(params = ["torrentList", "settings", "lastUpdated", "lastOpened", "lastOpenedId"]) {
    try {
        return await browser.storage.local.get(params);
    } catch (error) {
        throw Error(`load()->browser.storage.local.get: ${error.message}`);
    }
}

async function save(params) {
    try {
        return await browser.storage.local.set(params);
    } catch (error) {
        throw Error(`save()->browser.storage.local.set: ${error.message}`);
    }
}

// Singleton initialization promise to prevent race conditions during service worker wakeup
let initPromise = null;

async function ensureInitialized() {
    if (!initPromise) {
        initPromise = (async () => {
            try {
                const saved = await load(["settings"]);
                if (saved?.settings?.client && typeof updateClientOrigin === 'function') {
                    await updateClientOrigin(saved.settings.client);
                }
                if (typeof updateDisplayMode === 'function') {
                    await updateDisplayMode(saved?.settings?.displayMode || 'popup');
                }
            } catch (err) {
                console.warn("[Background] Initialization warning:", err);
            }
        })();
    }
    return initPromise;
}

// Initial start trigger
ensureInitialized().catch(() => {});

function popupMsgReceived(msg, sender, sendRes) {
    ensureInitialized().then(async () => {
        switch (msg.action) {
            case "update":
                updateTorrents()
                    .then(response => sendRes({ response }))
                    .catch(error => sendRes({ response: null, error: error.message || String(error) }));
                break;
            case "forcedUpdate":
                updateTorrents(true)
                    .then(response => sendRes({ response }))
                    .catch(error => sendRes({ response: null, error: error.message || String(error) }));
                break;
            case "searchApi":
                searchTorrentsApi(msg.options)
                    .then(response => sendRes({ response }))
                    .catch(error => sendRes({ response: null, error: error.message || String(error) }));
                break;
            case "getTorrentDrop":
                getTorrentDrop(msg.id)
                    .then(response => sendRes({ response }))
                    .catch(error => sendRes({ response: null, error: error.message || String(error) }));
                break;
            case "downloadTorrent":
                try {
                    const saved = await load(["settings"]);
                    const passkey = saved?.settings?.key ? saved.settings.key.trim() : '';
                    const downloadUrl = msg.downloadUrl || (passkey
                        ? `https://ncore.pro/torrents.php?action=download&id=${msg.id}&key=${passkey}`
                        : `https://ncore.pro/torrents.php?action=download&id=${msg.id}`);
                    const res = await sendToTorrentClient(saved?.settings?.client, downloadUrl, msg.title, msg.cat);
                    sendRes({ response: res });
                } catch (error) {
                    sendRes({ response: null, error: error.message || String(error) });
                }
                break;
            case "testClient":
                testTorrentClient(msg.client)
                    .then(res => sendRes({ response: res }))
                    .catch(error => sendRes({ response: null, error: error.message || String(error) }));
                break;
            case "getClientTorrents":
                try {
                    const saved = await load(["settings"]);
                    const clientConfig = msg.client || saved?.settings?.client;
                    const list = await getClientTorrents(clientConfig);
                    sendRes({ response: list });
                } catch (error) {
                    sendRes({ response: null, error: error.message || String(error) });
                }
                break;
            case "controlTorrentClient":
                try {
                    const saved = await load(["settings"]);
                    const clientConfig = msg.client || saved?.settings?.client;
                    const res = await controlTorrentClient(clientConfig, msg.hash, msg.command);
                    sendRes({ response: res });
                } catch (error) {
                    sendRes({ response: null, error: error.message || String(error) });
                }
                break;
            case "checkUpdate":
                checkForExtensionUpdates(true)
                    .then(response => sendRes({ response }))
                    .catch(error => sendRes({ response: null, error: error.message || String(error) }));
                break;
            default:
                sendRes({ response: null, error: `Ismeretlen parancs: ${msg.action}` });
                break;
        }
    }).catch(err => {
        sendRes({ response: null, error: err.message || String(err) });
    });
    return true; // Keep message port open for asynchronous responses
}

function storageChanged(changes) {
    if (changes.settings) {
        const newInterval = changes.settings.newValue?.refreshInterval;
        const oldInterval = changes.settings.oldValue?.refreshInterval;
        if (newInterval !== undefined && newInterval !== oldInterval) {
            createAlarm(+newInterval);
        }
        if (changes.settings.newValue?.client && typeof updateClientOrigin === 'function') {
            updateClientOrigin(changes.settings.newValue.client);
        }
        if (changes.settings.newValue?.displayMode !== changes.settings.oldValue?.displayMode && typeof updateDisplayMode === 'function') {
            updateDisplayMode(changes.settings.newValue?.displayMode || 'popup');
        }
    }
}

browser.alarms.onAlarm.addListener(async a => {
    if (a.name === "check-extension-updates") {
        checkForExtensionUpdates(false).catch(() => {});
        return;
    }
    if (a.name !== alarmName) return;
    ensureInitialized().then(() => {
        updateTorrents().catch(error => console.error("Alarm->updateTorrents hiba:", error));
    });
});

async function handleStartup() {
    try {
        const savedData = await load(["settings"]);
        if (savedData?.settings?.client && typeof updateClientOrigin === 'function') {
            await updateClientOrigin(savedData.settings.client);
        }
        if (typeof updateDisplayMode === 'function') {
            await updateDisplayMode(savedData?.settings?.displayMode || 'popup');
        }
        if (savedData?.settings?.refreshInterval) {
            await createAlarm(+savedData.settings.refreshInterval);
        } else {
            await createAlarm();
        }
        await updateTorrents();
        browser.alarms.get("check-extension-updates").then(existing => {
            if (!existing) browser.alarms.create("check-extension-updates", { periodInMinutes: 1440 });
        }).catch(() => {});
        checkForExtensionUpdates(false).catch(() => {});
    } catch (error) {
        console.error("handleStartup error:", error);
    }
}

function initBadge() {
    if (browser.action?.setBadgeBackgroundColor) {
        browser.action.setBadgeBackgroundColor({ color: [14, 165, 233, 255] });
    }
    if (browser.action?.setBadgeTextColor) {
        browser.action.setBadgeTextColor({ color: "#ffffff" });
    }
}
initBadge();

browser.runtime.onInstalled.addListener(handleStartup);
browser.runtime.onStartup.addListener(handleStartup);

if (!browser.storage.local.onChanged.hasListener(storageChanged)) {
    browser.storage.local.onChanged.addListener(storageChanged);
}
if (!browser.runtime.onMessage.hasListener(popupMsgReceived)) {
    browser.runtime.onMessage.addListener(popupMsgReceived);
}
if (browser.action && browser.action.onClicked && !browser.action.onClicked.hasListener(actionIconClicked)) {
    browser.action.onClicked.addListener(actionIconClicked);
}