/**
 * Inline SVG icons using VanJS native SVG namespace support.
 * Replaces Font Awesome dependency (~231 KB) with ~3 KB of inline SVGs.
 * Usage: van.add(container, Icons.refresh())
 */
(() => {
  const { svg, path, line, polyline, circle, polygon, rect } = van.tags("http://www.w3.org/2000/svg");

  const svgBase = (...children) =>
    svg(
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: "18",
        height: "18",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        "stroke-width": "2",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        style: "vertical-align: -0.125em; display: inline-block;",
      },
      ...children
    );

  window.Icons = {
    // fa-arrows-rotate (refresh/sync)
    refresh: () =>
      svgBase(
        path({ d: "M21 2v6h-6" }),
        path({ d: "M3 12a9 9 0 0 1 15-6.7L21 8" }),
        path({ d: "M3 22v-6h6" }),
        path({ d: "M21 12a9 9 0 0 1-15 6.7L3 16" })
      ),

    // fa-arrow-up-short-wide (sort ascending)
    sortAsc: () =>
      svgBase(
        line({ x1: "4", y1: "6", x2: "11", y2: "6" }),
        line({ x1: "4", y1: "12", x2: "13", y2: "12" }),
        line({ x1: "4", y1: "18", x2: "16", y2: "18" }),
        path({ d: "M20 4l-3-3-3 3M17 7V1" })
      ),

    // fa-arrow-down-wide-short (sort descending)
    sortDesc: () =>
      svgBase(
        line({ x1: "4", y1: "6", x2: "16", y2: "6" }),
        line({ x1: "4", y1: "12", x2: "13", y2: "12" }),
        line({ x1: "4", y1: "18", x2: "11", y2: "18" }),
        path({ d: "M20 20l-3 3-3-3M17 17v6" })
      ),

    // fa-left-long (arrow left long)
    arrowLeft: () =>
      svgBase(
        line({ x1: "19", y1: "12", x2: "5", y2: "12" }),
        polyline({ points: "12 19 5 12 12 5" })
      ),

    // fa-right-long (arrow right long)
    arrowRight: () =>
      svgBase(
        line({ x1: "5", y1: "12", x2: "19", y2: "12" }),
        polyline({ points: "12 5 19 12 12 19" })
      ),

    // fa-x (close/clear)
    close: () =>
      svgBase(
        line({ x1: "18", y1: "6", x2: "6", y2: "18" }),
        line({ x1: "6", y1: "6", x2: "18", y2: "18" })
      ),

    // fa-filter
    filter: () =>
      svgBase(
        polyline({ points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" })
      ),

    // filter-off (disabled state)
    filterOff: () =>
      svgBase(
        polyline({ points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" }),
        line({ x1: "2", y1: "2", x2: "22", y2: "22", stroke: "var(--danger)", "stroke-width": "2", "stroke-linecap": "round" })
      ),

    // fa-gear (settings)
    gear: () =>
      svgBase(
        path({ d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" }),
        circle({ cx: "12", cy: "12", r: "3" })
      ),

    // fa-save (floppy disk)
    save: () =>
      svgBase(
        path({ d: "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" }),
        polyline({ points: "17 21 17 13 7 13 7 21" }),
        polyline({ points: "7 3 7 8 15 8" })
      ),

    // download
    download: () =>
      svgBase(
        path({ d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }),
        polyline({ points: "7 10 12 15 17 10" }),
        line({ x1: "12", y1: "15", x2: "12", y2: "3" })
      ),

    // copy
    copy: () =>
      svgBase(
        path({ d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" }),
        path({ d: "M15 2H9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1z" })
      ),

    // check (checkmark)
    check: () =>
      svgBase(
        polyline({ points: "20 6 9 17 4 12" })
      ),

    // checkAll (double check / mark all read)
    checkAll: () =>
      svgBase(
        path({ d: "M18 6L7 17l-5-5" }),
        path({ d: "M22 10l-7.5 7.5-1.5-1.5" })
      ),

    // bell (notifications)
    bell: () =>
      svgBase(
        path({ d: "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" }),
        path({ d: "M13.73 21a2 2 0 0 1-3.46 0" })
      ),

    // server (client webui)
    server: () =>
      svgBase(
        path({ d: "M2 4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4z" }),
        path({ d: "M2 14a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-4z" }),
        line({ x1: "6", y1: "6", x2: "6.01", y2: "6" }),
        line({ x1: "6", y1: "16", x2: "6.01", y2: "16" })
      ),

    // bolt (lightning - unread/new items)
    bolt: () =>
      svgBase(
        polygon({ points: "13 2 3 14 12 14 11 22 21 10 12 10 13 2" })
      ),

    // spark (alias to bolt for backward compatibility)
    spark: () =>
      svgBase(
        polygon({ points: "13 2 3 14 12 14 11 22 21 10 12 10 13 2" })
      ),

    // clock
    clock: () =>
      svgBase(
        circle({ cx: "12", cy: "12", r: "10" }),
        polyline({ points: "12 6 12 12 16 14" })
      ),

    // alert
    alert: () =>
      svgBase(
        circle({ cx: "12", cy: "12", r: "10" }),
        line({ x1: "12", y1: "8", x2: "12", y2: "12" }),
        line({ x1: "12", y1: "16", x2: "12.01", y2: "16" })
      ),

    // database / cache
    database: () =>
      svgBase(
        path({ d: "M12 2C6.48 2 2 3.79 2 6s4.48 4 10 4 10-1.79 10-4-4.48-4-10-4z" }),
        path({ d: "M2 6v6c0 2.21 4.48 4 10 4s10-1.79 10-4V6" }),
        path({ d: "M2 12v6c0 2.21 4.48 4 10 4s10-1.79 10-4v-6" })
      ),

    // search
    search: () =>
      svgBase(
        circle({ cx: "11", cy: "11", r: "8" }),
        line({ x1: "21", y1: "21", x2: "16.65", y2: "16.65" })
      ),

    // info
    info: () =>
      svgBase(
        circle({ cx: "12", cy: "12", r: "10" }),
        line({ x1: "12", y1: "16", x2: "12", y2: "12" }),
        line({ x1: "12", y1: "8", x2: "12.01", y2: "8" })
      ),

    // external link
    external: () =>
      svgBase(
        path({ d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }),
        polyline({ points: "15 3 21 3 21 9" }),
        line({ x1: "10", y1: "14", x2: "21", y2: "3" })
      ),

    // play (media / trailer)
    play: () =>
      svgBase(
        polygon({ points: "5 3 19 12 5 21 5 3" })
      ),

    // star outline (unbookmarked)
    starOutline: () =>
      svgBase(
        path({ d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" })
      ),

    // star filled (bookmarked)
    starFilled: () =>
      svgBase(
        path({
          d: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
          fill: "var(--warning, #f59e0b)",
          stroke: "var(--warning, #f59e0b)"
        })
      ),

    // chevronDown (expand accordion)
    chevronDown: () =>
      svgBase(
        polyline({ points: "6 9 12 15 18 9" })
      ),

    // chevronUp (collapse accordion)
    chevronUp: () =>
      svgBase(
        polyline({ points: "18 15 12 9 6 15" })
      ),

    // eye (preview / poster)
    eye: () =>
      svgBase(
        path({ d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }),
        circle({ cx: "12", cy: "12", r: "3" })
      ),

    // image (screenshots)
    image: () =>
      svgBase(
        path({ d: "M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z" }),
        circle({ cx: "8.5", cy: "8.5", r: "1.5" }),
        polyline({ points: "21 15 16 10 5 21" })
      ),

    // tag
    tag: () =>
      svgBase(
        path({ d: "M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" }),
        line({ x1: "7", y1: "7", x2: "7.01", y2: "7" })
      ),

    // fileText (NFO / specs)
    fileText: () =>
      svgBase(
        path({ d: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }),
        polyline({ points: "14 2 14 8 20 8" }),
        line({ x1: "16", y1: "13", x2: "8", y2: "13" }),
        line({ x1: "16", y1: "17", x2: "8", y2: "17" }),
        polyline({ points: "10 9 9 9 8 9" })
      ),

    // globe (live search)
    globe: () =>
      svgBase(
        circle({ cx: "12", cy: "12", r: "10" }),
        line({ x1: "2", y1: "12", x2: "22", y2: "12" }),
        path({ d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" })
      ),

    // messageSquare (comments)
    messageSquare: () =>
      svgBase(
        path({ d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" })
      ),

    // folder (files)
    folder: () =>
      svgBase(
        path({ d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" })
      ),

    // user (uploader)
    user: () =>
      svgBase(
        path({ d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" }),
        circle({ cx: "12", cy: "7", r: "4" })
      ),

    // clock (upload datetime)
    clock: () =>
      svgBase(
        circle({ cx: "12", cy: "12", r: "10" }),
        polyline({ points: "12 6 12 12 16 14" })
      ),

    // keyboard (shortcuts)
    keyboard: () =>
      svgBase(
        rect({ x: "2", y: "4", width: "20", height: "16", rx: "2", ry: "2" }),
        line({ x1: "6", y1: "8", x2: "6", y2: "8" }),
        line({ x1: "10", y1: "8", x2: "10", y2: "8" }),
        line({ x1: "14", y1: "8", x2: "14", y2: "8" }),
        line({ x1: "18", y1: "8", x2: "18", y2: "8" }),
        line({ x1: "6", y1: "12", x2: "6", y2: "12" }),
        line({ x1: "10", y1: "12", x2: "10", y2: "12" }),
        line({ x1: "14", y1: "12", x2: "14", y2: "12" }),
        line({ x1: "18", y1: "12", x2: "18", y2: "12" }),
        line({ x1: "7", y1: "16", x2: "17", y2: "16" })
      ),

    // helpCircle (help / guide)
    helpCircle: () =>
      svgBase(
        circle({ cx: "12", cy: "12", r: "10" }),
        path({ d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" }),
        line({ x1: "12", y1: "17", x2: "12.01", y2: "17" })
      ),

    // play (resume download)
    play: () =>
      svgBase(
        polygon({ points: "5 3 19 12 5 21 5 3" })
      ),

    // pause (pause download)
    pause: () =>
      svgBase(
        rect({ x: "6", y: "4", width: "4", height: "16" }),
        rect({ x: "14", y: "4", width: "4", height: "16" })
      ),

    // sidebar (layout sidebar)
    sidebar: () =>
      svgBase(
        rect({ x: "3", y: "3", width: "18", height: "18", rx: "2", ry: "2" }),
        line({ x1: "9", y1: "3", x2: "9", y2: "21" })
      ),

    // popup (modal window)
    popup: () =>
      svgBase(
        rect({ x: "3", y: "3", width: "18", height: "18", rx: "2", ry: "2" }),
        rect({ x: "7", y: "7", width: "10", height: "10", rx: "1" })
      ),
  };
})();
