/**
 * ui.js - UI Root Helpers & Dropdown Coordination
 * Individual components are modularized in ui/*.js:
 *   - ui/header.js: Header bar
 *   - ui/accordion.js: Accordion details panel
 *   - ui/torrent-item.js: Torrent row card
 *   - ui/torrent-list.js: Virtual list container, banners, and empty states
 *   - ui/settings-modal.js: Settings dialog with 5 tabs
 *   - ui/footer.js: Footer bar, filters and search
 */

function openHelpModal() {
  activeSettingsTab.val = "help";
  const settingDropdown = document.getElementById("setting");
  if (settingDropdown && !settingDropdown.classList.contains("is-active")) {
    document.querySelectorAll(".dropdown.is-active").forEach(menu => menu.classList.remove("is-active"));
    settingDropdown.classList.add("is-active");
  }
}

function dropdownToggle(evt) {
  let target = evt.currentTarget.id;
  if (!target) return;
  target = target.replace("-btn", "");
  const dropUpMenus = document.querySelectorAll(".dropdown");
  dropUpMenus.forEach(menu => {
    if (target === menu.id) menu.classList.toggle("is-active");
    else menu.classList.remove("is-active");
  });
}

document.addEventListener("click", (e) => {
  if (!e.target.closest(".dropdown")) {
    document.querySelectorAll(".dropdown.is-active").forEach(menu => menu.classList.remove("is-active"));
  }
});
