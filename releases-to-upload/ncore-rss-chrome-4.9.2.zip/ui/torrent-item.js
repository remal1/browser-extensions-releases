/**
 * ui/torrent-item.js - Torrent Card / Row Item Component
 */

function renderTorrentItem(v, index) {
  const { a, button, div, span, img } = van.tags;

  const isBookmarked = () => bookmarks.val.includes(v.id);
  const isExpanded = () => expandedTorrentId.val === v.id;

  return div({ class: "torrent-card-container flex flex-col", "data-id": v.id },
    div({
      class: () => `list-item ${focusedIndex.val === index ? 'is-focused' : ''}`,
      onclick: (e) => {
        if (e.button === 0) handleTorrentClick(e, v?.link);
      },
      onmousedown: (e) => {
        if (e.button === 1) {
          e.preventDefault();
        }
      },
      onmouseup: (e) => {
        if (e.button === 1) {
          e.preventDefault();
          handleTorrentClick(e, v?.link);
        }
      },
      onauxclick: (e) => {
        if (e.button === 1) {
          e.preventDefault();
          handleTorrentClick(e, v?.link);
        }
      },
      title: () => {
        const catDef = v?._catDef || (typeof resolveCategory === 'function' ? resolveCategory(v?.cat, v?.title) : null);
        const catLabel = catDef ? catDef.label : (v?.cat || "Ismeretlen");
        return `Név: ${v?.title}\nKategória: ${catLabel}${v?.pubDate ? `\nFeltöltve: ${new Date(v?.pubDate).toLocaleString('hu-HU', { timeZone: 'Europe/Budapest' })}` : ''}\n\nKattintás: megnyitás\nKözépső klikk / Ctrl+Klikk: megnyitás háttérlapon`;
      }
    },
      () => {
        const ct = getClientTorrent(v.id);
        if (!ct || currentSettings?.client?.showProgress === false || currentSettings?.client?.type === 'browser') {
          return "";
        }
        const pct = Math.min(100, Math.max(0, Math.round((ct.progress || 0) * 100)));
        const paused = isTorrentPaused(ct.state);
        const done = ct.progress >= 1;
        const statusClass = done ? 'is-completed' : (paused ? 'is-paused' : 'is-downloading');
        return div({
          class: `list-item-progress ${statusClass}`,
          style: `width: ${pct}%;`
        });
      },
      div({
        class: () => {
          const isNew = v.id > lastOpenedId.val || (v.pubDate && v.pubDate > lastOpened.val);
          return `list-item-indicator ${isNew ? "is-new" : visited.includes(v?.link) ? "is-visited" : ""}`;
        },
        title: () => {
          const isNew = v.id > lastOpenedId.val || (v.pubDate && v.pubDate > lastOpened.val);
          return isNew ? "Új torrent" : visited.includes(v?.link) ? "Már megnyitott torrent" : "";
        }
      }),
      div({ class: "list-item-image" },
        img({
          src: () => {
            const catDef = v?._catDef || (typeof resolveCategory === 'function' ? resolveCategory(v?.cat, v?.title) : null);
            return catDef?.path || ((typeof categories !== 'undefined' && categories[v?.cat]?.path) || 'icons/default.png');
          },
          alt: () => {
            const catDef = v?._catDef || (typeof resolveCategory === 'function' ? resolveCategory(v?.cat, v?.title) : null);
            return catDef?.label || v?.cat || '';
          }
        })
      ),
      div({ class: "list-item-content", style: "display: flex; align-items: center; width: 100%; gap: 0.5rem; justify-content: space-between;" },
        span({ class: "list-item-title", style: "flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" }, () => v?.title),
        div({ style: "display: flex; align-items: center; gap: 0.4rem; flex-shrink: 0;" },
          () => (searchMode.val !== 'api' && v?.freeleech) ? span({ class: "badge-freeleech" }, "FREE") : "",
          () => (v?.imdbRating && v?.imdbId)
            ? a({
                class: "badge-imdb",
                href: `https://www.imdb.com/title/${v.imdbId}/`,
                target: "_blank",
                onclick: (e) => e.stopPropagation(),
                title: "Megnyitás az IMDb-n"
              }, `⭐ ${v.imdbRating}`)
            : "",
          () => v?.pubDate ? span({ class: "list-item-date", title: new Date(v.pubDate).toLocaleString('hu-HU') }, formatRelativeTime(v.pubDate)) : "",
          () => v?.size ? span({ class: "text-muted text-xs whitespace-nowrap" }, formatBytes(v.size)) : "",
          () => v?.seeders != null ? span({ class: "text-success font-semibold text-xs whitespace-nowrap", title: "Seeders" }, "S: ", () => v.seeders) : "",
          () => v?.leechers != null ? span({ class: "text-danger font-semibold text-xs whitespace-nowrap", title: "Leechers" }, "L: ", () => v.leechers) : "",
          () => {
            const ct = getClientTorrent(v.id);
            if (!ct || currentSettings?.client?.showProgress === false || currentSettings?.client?.type === 'browser') return "";
            const pct = Math.min(100, Math.max(0, Math.round((ct.progress || 0) * 100)));
            const paused = isTorrentPaused(ct.state);
            const done = ct.progress >= 1;
            const speedStr = ct.dlspeed > 0 ? ` · ${formatBytes(ct.dlspeed)}/s` : (ct.upspeed > 0 && done ? ` · ${formatBytes(ct.upspeed)}/s` : '');
            const etaStr = ct.eta > 0 && ct.eta < 864000 ? ` (ETA: ${formatEta(ct.eta)})` : '';
            const statusClass = done ? 'is-completed' : (paused ? 'is-paused' : 'is-downloading');
            const label = done ? '100%' : `${pct}%${speedStr}`;
            return span({
              class: `progress-badge ${statusClass}`,
              title: `Kliens állapot: ${ct.state || ''}${speedStr}${etaStr}`
            }, label);
          },
          div({ class: "list-item-actions" },
            button({
              class: () => `action-btn btn-star ${isBookmarked() ? 'is-bookmarked' : ''}`,
              onclick: (e) => toggleBookmark(e, v),
              title: () => isBookmarked() ? "Eltávolítás a könyvjelzőkből" : "Hozzáadás a könyvjelzőkhöz"
            }, () => isBookmarked() ? Icons.starFilled() : Icons.starOutline()),
            () => {
              const ct = getClientTorrent(v.id);
              const hasClient = ct && currentSettings?.client?.type && currentSettings.client.type !== 'browser';
              if (!hasClient) {
                return button({
                  class: "action-btn",
                  onclick: (e) => handleDownload(e, v),
                  title: "Letöltés / Kliensbe küldés"
                }, Icons.download());
              }

              const paused = isTorrentPaused(ct.state);
              const done = ct.progress >= 1;

              if (done) {
                return button({
                  class: "action-btn btn-client is-completed",
                  onclick: (e) => handleClientToggle(e, v),
                  title: paused ? "Befejezve (Szüneteltetve) - Kattints az indításhoz" : "Befejezve (Seedel) - Kattints a szüneteltetéshez"
                }, paused ? Icons.play() : Icons.check());
              }

              if (paused) {
                return button({
                  class: "action-btn btn-client is-paused",
                  onclick: (e) => handleClientToggle(e, v),
                  title: `Szüneteltetve (${Math.round((ct.progress || 0) * 100)}%) - Kattints a folytatáshoz`
                }, Icons.play());
              }

              return button({
                class: "action-btn btn-client is-downloading",
                onclick: (e) => handleClientToggle(e, v),
                title: `Letöltés (${Math.round((ct.progress || 0) * 100)}%) - Kattints a szüneteltetéshez`
              }, Icons.pause());
            },
            button({
              class: () => `action-btn btn-preview ${hoverPreview.val.visible && hoverPreview.val.id === v.id ? 'active' : ''}`,
              onmouseenter: (e) => showPosterPreview(e, v),
              onmouseleave: hidePosterPreview,
              onclick: (e) => {
                e.stopPropagation();
                if (hoverPreview.val.visible && hoverPreview.val.id === v.id) {
                  hidePosterPreview();
                } else {
                  showPosterPreview(e, v);
                }
              },
              title: "Borítókép és gyors előnézet"
            }, Icons.eye()),
            button({
              class: () => `action-btn ${isExpanded() ? 'active' : ''}`,
              onclick: (e) => toggleAccordion(e, v),
              title: () => isExpanded() ? "Részletek bezárása" : "Részletek és mintaképek megnyitása"
            }, () => isExpanded() ? Icons.chevronUp() : Icons.chevronDown())
          )
        )
      )
    ),
    () => {
      getDropTrigger(v.id).val;
      const expanded = isExpanded();
      if (expanded) {
        scrollAccordionIntoView(v.id);
      }
      return expanded ? renderAccordion(v) : "";
    }
  );
}
