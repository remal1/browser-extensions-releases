/**
 * ui/header.js - Header Bar Component
 */

function addHeader() {
  const { a, button, div, span, img } = van.tags;

  const updated = van.derive(() =>
    lastUpdated.val
      ? new Date(lastUpdated.val).toLocaleString('hu-HU', { timeZone: 'Europe/Budapest' })
      : "–"
  );

  const generateToast = () => {
    return div({ class: "toast-container" },
      () => toastMessage.val
        ? div({ class: () => `toast-msg toast-${toastType.val}` },
            () => toastType.val === 'error'
              ? Icons.alert()
              : (toastType.val === 'warning'
                  ? Icons.alert()
                  : (toastType.val === 'info' ? Icons.info() : Icons.check())),
            span(toastMessage.val)
          )
        : ""
    );
  };

  const generate = () => {
    return div({ class: "header-bar flex items-center justify-between" },
      div({ class: "flex items-center gap-2" },
        span({ class: "font-semibold" }, "Utolsó frissítés:"),
        span({
          class: () => `text-muted ${isCached.val ? 'text-warning font-semibold' : ''}`,
          title: () => isCached.val ? "A lista nem frissült, a legutóbbi mentett állapot látható" : "Sikeresen frissítve"
        }, () => lastUpdated.val ? new Date(lastUpdated.val).toLocaleString('hu-HU', { timeZone: 'Europe/Budapest' }) : "–"),
        button({ class: "btn btn-icon", onclick: () => updateTorrentsList(true), title: "Frissítés most" },
          Icons.refresh()
        )
      ),
      div({ class: "header-badge flex items-center gap-2" },
        span({ class: "badge badge-glass" }, listLength, " torrent"),
        () => isCached.val
          ? span({
              class: "badge badge-warning",
              title: "A megjelenített lista a helyi gyorsítótárból származik."
            },
            Icons.database(),
            "Gyorsítótár"
          )
          : ""
      ),
      div({ class: "header-logo-group" },
        a({ class: "logo", href: "https://ncore.pro/", target: "_blank", title: "Megnyitás az nCore-on" },
          img({ src: "icons/ncore.png", alt: "nCore logo" })
        ),
        span({ class: "header-version" }, `v${browser.runtime.getManifest().version}`),
        () => updateInfo.val?.hasUpdate
          ? a({
              class: "badge badge-update",
              href: updateInfo.val?.releasePage || "https://github.com/remal1/browser-extensions-releases/releases",
              target: "_blank",
              title: `Új verzió érhető el: v${updateInfo.val?.latestVersion}! Kattints a kiadási oldalhoz.`
            },
            "✨ Új v" + updateInfo.val?.latestVersion
          )
          : ""
      )
    );
  };
  van.add(document.querySelector("#header"), generate());
  van.add(document.body, generateToast());
}
