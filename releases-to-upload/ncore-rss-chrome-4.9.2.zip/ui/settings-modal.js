/**
 * ui/settings-modal.js - Settings Dropdown Modal & Tabs Component
 */

function renderSettingsModal() {
  const { a, p, button, div, span, input, label, select, option, textarea, kbd } = van.tags;
  const activeTab = activeSettingsTab;
  const useCategoryPathsState = van.state(Boolean(currentSettings?.client?.useCategoryPaths));
  const useHttpAuthState = van.state(Boolean(currentSettings?.client?.useHttpAuth));

  const DataSourceSelector = () => {
    const setSource = async (source) => {
      if (currentSettings.dataSource === source) return;
      currentSettings.dataSource = source;
      errorMessage.val = "";
      await save({ settings: currentSettings });
      await updateTorrentsList(true);
    };

    const SourceBtn = (lbl, val) => button({
      class: () => `btn ${currentSettings.dataSource === val ? 'active' : ''}`,
      onclick: () => setSource(val),
      title: `Váltás ${lbl} módra`
    }, lbl);

    return div({ class: "btn-group" },
      SourceBtn("RSS", "rss"),
      SourceBtn("APIv1", "apiv1"),
      SourceBtn("APIv2", "apiv2")
    );
  };

  const DisplayModeSelector = () => {
    const setMode = (mode) => {
      currentSettings.displayMode = mode;
    };

    const ModeBtn = (lbl, val, icon) => button({
      class: () => `btn flex-1 ${(!currentSettings?.displayMode && val === 'popup') || currentSettings?.displayMode === val ? 'active' : ''}`,
      onclick: (e) => { e.preventDefault(); setMode(val); },
      style: "display: flex; align-items: center; justify-content: center; gap: 0.35rem; font-size: 0.8rem; padding: 0.35rem 0.5rem;"
    }, icon, lbl);

    return div({ class: "btn-group", style: "width: 100%;" },
      ModeBtn("Felugró ablak", "popup", Icons.popup ? Icons.popup() : null),
      ModeBtn("Oldalsáv", "sidebar", Icons.sidebar ? Icons.sidebar() : null)
    );
  };

  return div({
    class: "dropdown-menu",
    id: "settings-container",
    style: "width: 340px; display: flex; flex-direction: column; height: 540px;"
  },
    div({ class: "btn-group", style: "width: 100%; margin-bottom: 0.75rem; flex-shrink: 0;" },
      button({
        class: () => `btn nav-tab-btn ${activeTab.val === "settings" ? "active" : ""}`,
        style: "flex: 1;",
        onclick: (e) => { e.preventDefault(); e.stopPropagation(); activeTab.val = "settings"; }
      }, "Alap"),
      button({
        class: () => `btn nav-tab-btn ${activeTab.val === "client" ? "active" : ""}`,
        style: "flex: 1;",
        onclick: (e) => { e.preventDefault(); e.stopPropagation(); activeTab.val = "client"; }
      }, "Kliens"),
      button({
        class: () => `btn nav-tab-btn ${activeTab.val === "notifications" ? "active" : ""}`,
        style: "flex: 1;",
        onclick: (e) => { e.preventDefault(); e.stopPropagation(); activeTab.val = "notifications"; }
      }, "Értesítés"),
      button({
        class: () => `btn nav-tab-btn ${activeTab.val === "help" ? "active" : ""}`,
        style: "flex: 1;",
        onclick: (e) => { e.preventDefault(); e.stopPropagation(); activeTab.val = "help"; }
      }, "Súgó")
    ),

    // Tab 1: Alapbeállítások
    div({ class: () => `tab-content ${activeTab.val === "settings" ? "active" : ""}` },
      div({ class: "form-group" },
        label({ class: "form-label" }, "Adatforrás"),
        DataSourceSelector()
      ),
      div({ class: "form-group" },
        label({ class: "form-label" }, "nCore Passkey"),
        input({
          class: "input",
          type: "password",
          value: () => currentSettings?.key ?? "",
          onchange: e => currentSettings.key = e.target.value
        }),
        p({ class: "form-help" }, "A 'Profil > Egyéb adatok' oldalon találod a Passkeyedet")
      ),
      div({ class: "flex gap-2" },
        div({ class: "form-group flex-1", style: "min-width: 0;" },
          label({ class: "form-label" }, "Frissítés"),
          div({ class: "select" },
            select({ onchange: e => currentSettings.refreshInterval = e.target.value },
              option({ value: "0", selected: () => currentSettings?.refreshInterval === "0" }, "Ki"),
              option({ value: "1", selected: () => currentSettings?.refreshInterval === "1" }, "1 p"),
              option({ value: "2", selected: () => currentSettings?.refreshInterval === "2" }, "2 p"),
              option({ value: "3", selected: () => currentSettings?.refreshInterval === "3" }, "3 p"),
              option({ value: "5", selected: () => currentSettings?.refreshInterval === "5" }, "5 p"),
              option({ value: "10", selected: () => currentSettings?.refreshInterval === "10" }, "10 p"),
              option({ value: "15", selected: () => currentSettings?.refreshInterval === "15" }, "15 p"),
              option({ value: "30", selected: () => currentSettings?.refreshInterval === "30" }, "30 p"),
              option({ value: "60", selected: () => currentSettings?.refreshInterval === "60" }, "60 p"),
            )
          ),
          p({ class: "form-help" }, "Gyakoriság")
        ),
        div({ class: "form-group flex-1", style: "min-width: 0;" },
          label({ class: "form-label" }, "Téma"),
          div({ class: "select" },
            select({
              onchange: e => {
                currentSettings.theme = e.target.value;
                if (e.target.value === "system") {
                  document.documentElement.removeAttribute("data-theme");
                } else {
                  document.documentElement.setAttribute("data-theme", e.target.value);
                }
              }
            },
              option({ value: "system", selected: () => currentSettings?.theme === "system" || !currentSettings?.theme }, "Auto"),
              option({ value: "light", selected: () => currentSettings?.theme === "light" }, "Világos"),
              option({ value: "dark", selected: () => currentSettings?.theme === "dark" }, "Sötét")
            )
          ),
          p({ class: "form-help" }, "Megjelenés")
        )
      ),
      div({ class: "form-group" },
        label({ class: "form-label" }, "Megjelenés módja"),
        DisplayModeSelector(),
        p({ class: "form-help" }, "Kattintásra felugró ablak vagy rögzített oldalsáv nyíljon meg")
      ),
      div({ class: "flex gap-4", style: "margin-bottom: 1rem;" },
        div({ class: "flex items-center gap-2 flex-1", style: "min-width: 0;" },
          label({ class: "switch" },
            input({
              id: "scrollToNew-toggle",
              type: "checkbox",
              checked: () => currentSettings?.scrollToNew ?? false,
              onchange: e => currentSettings.scrollToNew = e.target.checked
            }),
            span({ class: "slider" })
          ),
          label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer; white-space: nowrap; font-weight: 400;", for: "scrollToNew-toggle" }, "Ugrás az újra")
        ),
        div({ class: "flex items-center gap-2 flex-1", style: "min-width: 0;" },
          label({ class: "switch" },
            input({
              id: "newTab-toggle",
              type: "checkbox",
              checked: () => currentSettings?.showInNewTab,
              onchange: e => currentSettings.showInNewTab = e.target.checked
            }),
            span({ class: "slider" })
          ),
          label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer; white-space: nowrap; font-weight: 400;", for: "newTab-toggle" }, "Új fülön nyílik")
        )
      ),
      div({ style: "margin-top: auto;" },
        button({ class: "btn btn-primary", onclick: saveUserSettings, style: "width: 100%; display: flex; justify-content: center; gap: 0.5rem;" },
          Icons.save(),
          "Mentés"
        )
      )
    ),

    // Tab 2: Torrent Kliens Integráció
    div({ class: () => `tab-content ${activeTab.val === "client" ? "active" : ""}` },
      div({ class: "form-group" },
        label({ class: "form-label" }, "Kliens típus"),
        div({ class: "select" },
          select({
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.type = e.target.value;
            }
          },
            option({ value: "browser", selected: () => !currentSettings?.client?.type || currentSettings?.client?.type === "browser" }, "Böngészős letöltés (.torrent)"),
            option({ value: "qbittorrent", selected: () => currentSettings?.client?.type === "qbittorrent" }, "qBittorrent (WebUI)"),
            option({ value: "transmission", selected: () => currentSettings?.client?.type === "transmission" }, "Transmission (RPC)")
          )
        )
      ),
      div({ class: "form-group" },
        label({ class: "form-label" }, "Szerver URL"),
        input({
          class: "input",
          placeholder: "pl. http://localhost:8080",
          value: () => currentSettings?.client?.url ?? "",
          onchange: e => {
            if (!currentSettings.client) currentSettings.client = {};
            currentSettings.client.url = e.target.value;
          }
        }),
        p({ class: "form-help" }, "A torrent kliens WebUI elérési címe")
      ),
      div({ class: "flex gap-2" },
        div({ class: "form-group flex-1", style: "min-width: 0;" },
          label({ class: "form-label" }, "Felhasználónév"),
          input({
            class: "input",
            placeholder: "admin",
            value: () => currentSettings?.client?.username ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.username = e.target.value;
            }
          })
        ),
        div({ class: "form-group flex-1", style: "min-width: 0;" },
          label({ class: "form-label" }, "Jelszó"),
          input({
            class: "input",
            type: "password",
            placeholder: "••••••••",
            value: () => currentSettings?.client?.password ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.password = e.target.value;
            }
          })
        )
      ),
      div({ class: "form-group" },
        label({ class: "form-label" }, "Kategória / Címke (opcionális)"),
        input({
          class: "input",
          placeholder: "pl. ncore",
          value: () => currentSettings?.client?.category ?? "",
          onchange: e => {
            if (!currentSettings.client) currentSettings.client = {};
            currentSettings.client.category = e.target.value;
          }
        })
      ),
      div({ class: "form-group" },
        label({ class: "form-label" }, "Letöltési könyvtár (opcionális)"),
        input({
          class: "input",
          placeholder: "pl. /downloads vagy D:\\Torrents",
          value: () => currentSettings?.client?.savepath ?? "",
          onchange: e => {
            if (!currentSettings.client) currentSettings.client = {};
            currentSettings.client.savepath = e.target.value;
          }
        }),
        p({ class: "form-help" }, "Alapértelmezett letöltési mappa a kliensben")
      ),
      div({ class: "flex items-center gap-2", style: "margin-top: 0.25rem; margin-bottom: 0.25rem;" },
        label({ class: "switch" },
          input({
            id: "usecatpaths-toggle",
            type: "checkbox",
            checked: () => useCategoryPathsState.val,
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.useCategoryPaths = e.target.checked;
              useCategoryPathsState.val = e.target.checked;
            }
          }),
          span({ class: "slider" })
        ),
        label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer;", for: "usecatpaths-toggle" }, "Kategóriánkénti letöltési mappák")
      ),
      p({ class: "form-help", style: "margin-bottom: 0.5rem;" }, "Opcionális felülbírálás főkategóriánként (ha egy mező üres, az alapértelmezett mappa érvényes)."),
      () => useCategoryPathsState.val ? div({ class: "flex flex-col gap-2", style: "margin-bottom: 0.75rem; padding-left: 0.5rem; border-left: 2px solid var(--accent);" },
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "🎬 Filmek mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/Filmek",
            value: () => currentSettings?.client?.categoryPaths?.movie ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.movie = e.target.value;
            }
          })
        ),
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "📺 Sorozatok mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/Sorozatok",
            value: () => currentSettings?.client?.categoryPaths?.serie ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.serie = e.target.value;
            }
          })
        ),
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "🎵 Zenék mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/Zene",
            value: () => currentSettings?.client?.categoryPaths?.music ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.music = e.target.value;
            }
          })
        ),
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "🎮 Játékok mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/Jatekok",
            value: () => currentSettings?.client?.categoryPaths?.game ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.game = e.target.value;
            }
          })
        ),
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "💻 Programok mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/Programok",
            value: () => currentSettings?.client?.categoryPaths?.app ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.app = e.target.value;
            }
          })
        ),
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "📚 Könyvek mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/Konyvek",
            value: () => currentSettings?.client?.categoryPaths?.ebook ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.ebook = e.target.value;
            }
          })
        ),
        div({ class: "form-group", style: "margin-bottom: 0.25rem;" },
          label({ class: "form-label", style: "font-size: 0.72rem;" }, "🔞 XXX mappája"),
          input({
            class: "input",
            placeholder: "pl. /downloads/XXX",
            value: () => currentSettings?.client?.categoryPaths?.xxx ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              if (!currentSettings.client.categoryPaths) currentSettings.client.categoryPaths = {};
              currentSettings.client.categoryPaths.xxx = e.target.value;
            }
          })
        )
      ) : "",
      div({ class: "flex items-center gap-2", style: "margin-bottom: 0.25rem;" },
        label({ class: "switch" },
          input({
            id: "startimmediately-toggle",
            type: "checkbox",
            checked: () => currentSettings?.client?.startImmediately ?? false,
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.startImmediately = e.target.checked;
            }
          }),
          span({ class: "slider" })
        ),
        label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer;", for: "startimmediately-toggle" }, "Letöltés azonnali indítása")
      ),
      p({ class: "form-help", style: "margin-bottom: 0.75rem;" }, "Kikapcsolva a letöltés megállított (szüneteltetett) állapotban kerül hozzáadásra."),
      div({ class: "flex items-center gap-2", style: "margin-bottom: 0.25rem;" },
        label({ class: "switch" },
          input({
            id: "showprogress-toggle",
            type: "checkbox",
            checked: () => currentSettings?.client?.showProgress !== false,
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.showProgress = e.target.checked;
              if (e.target.checked) {
                startClientPolling();
              } else {
                stopClientPolling();
              }
            }
          }),
          span({ class: "slider" })
        ),
        label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer;", for: "showprogress-toggle" }, "Élő letöltési állapot és vezérlés")
      ),
      p({ class: "form-help", style: "margin-bottom: 0.5rem;" }, "A listában megjelenik a letöltési folyamat és a gombbal közvetlenül szüneteltethető vagy folytatható a letöltés."),
      () => (currentSettings?.client?.showProgress !== false) ? div({ class: "form-group", style: "margin-bottom: 0.75rem; padding-left: 0.5rem; border-left: 2px solid var(--accent);" },
        label({ class: "form-label", style: "font-size: 0.75rem;" }, "Állapot frissítési gyakorisága"),
        div({ class: "select-wrapper", style: "margin-top: 0.25rem;" },
          select({
            class: "select",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.pollInterval = parseInt(e.target.value, 10);
              startClientPolling();
            }
          },
            option({ value: "1", selected: () => (currentSettings?.client?.pollInterval || 2) == 1 }, "1 másodperc"),
            option({ value: "2", selected: () => (currentSettings?.client?.pollInterval || 2) == 2 }, "2 másodperc (Ajánlott)"),
            option({ value: "3", selected: () => (currentSettings?.client?.pollInterval || 2) == 3 }, "3 másodperc"),
            option({ value: "5", selected: () => (currentSettings?.client?.pollInterval || 2) == 5 }, "5 másodperc"),
            option({ value: "10", selected: () => (currentSettings?.client?.pollInterval || 2) == 10 }, "10 másodperc")
          )
        )
      ) : "",
      div({ class: "flex items-center gap-2", style: "margin-bottom: 0.75rem;" },
        label({ class: "switch" },
          input({
            id: "httpauth-toggle",
            type: "checkbox",
            checked: () => useHttpAuthState.val,
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.useHttpAuth = e.target.checked;
              useHttpAuthState.val = e.target.checked;
            }
          }),
          span({ class: "slider" })
        ),
        label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer;", for: "httpauth-toggle" }, "HTTP Basic Auth használata")
      ),
      () => useHttpAuthState.val ? div({ class: "flex gap-2", style: "margin-bottom: 0.75rem;" },
        div({ class: "form-group flex-1", style: "min-width: 0;" },
          label({ class: "form-label" }, "HTTP Felhasználó"),
          input({
            class: "input",
            placeholder: "Üres = WebUI adat",
            value: () => currentSettings?.client?.httpUsername ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.httpUsername = e.target.value;
            }
          })
        ),
        div({ class: "form-group flex-1", style: "min-width: 0;" },
          label({ class: "form-label" }, "HTTP Jelszó"),
          input({
            class: "input",
            type: "password",
            placeholder: "Üres = WebUI adat",
            value: () => currentSettings?.client?.httpPassword ?? "",
            onchange: e => {
              if (!currentSettings.client) currentSettings.client = {};
              currentSettings.client.httpPassword = e.target.value;
            }
          })
        )
      ) : "",
      div({ class: "flex items-center gap-2", style: "margin-bottom: 1rem;" },
        button({ class: "btn", onclick: runTestClient, style: "flex: 1; display: flex; justify-content: center; gap: 0.5rem;" },
          Icons.server(),
          "Kapcsolat tesztelése"
        )
      ),
      () => testClientStatus.val ? div({
        class: () => `client-status-card client-status-${testClientType.val}`
      },
        div({ class: "client-status-icon" },
          () => testClientType.val === 'success'
            ? Icons.check()
            : (testClientType.val === 'error'
                ? Icons.alert()
                : (testClientType.val === 'loading' ? Icons.refresh() : Icons.info()))
        ),
        div({ class: "client-status-text" }, testClientStatus.val)
      ) : "",
      div({ style: "margin-top: auto;" },
        button({ class: "btn btn-primary", onclick: saveUserSettings, style: "width: 100%; display: flex; justify-content: center; gap: 0.5rem;" },
          Icons.save(),
          "Mentés"
        )
      )
    ),

    // Tab 3: Értesítések
    div({ class: () => `tab-content ${activeTab.val === "notifications" ? "active" : ""}` },
      div({ class: "flex items-center gap-2", style: "margin-bottom: 1rem;" },
        label({ class: "switch" },
          input({
            id: "notif-toggle",
            type: "checkbox",
            checked: () => currentSettings?.enableNotifications ?? false,
            onchange: e => currentSettings.enableNotifications = e.target.checked
          }),
          span({ class: "slider" })
        ),
        label({ class: "form-label", style: "margin-bottom: 0; cursor: pointer;", for: "notif-toggle" }, "Értesítések engedélyezése")
      ),
      div({ class: "form-group", style: "flex: 1; display: flex; flex-direction: column;" },
        label({ class: "form-label" }, "Figyelt kifejezések és minták (soronként)"),
        textarea({
          class: "input",
          style: "flex: 1; min-height: 140px; font-family: monospace; font-size: 0.85rem;",
          placeholder: "pl.:\nHouse of the Dragon 2160p\nDune 2160p -CAM -TS\nForma-1 1080p HUN\n/Cyberpunk.*(2160p|4k)/i",
          value: () => currentSettings?.keywords ?? "",
          onchange: e => currentSettings.keywords = e.target.value
        }),
        p({ class: "form-help", style: "line-height: 1.4; margin-top: 0.5rem;" },
          "• Egy soron belül minden szónak egyeznie kell (szóköz / pont függetlenül).",
          div({ style: "margin-top: 2px;" }, "• Kizárás: szó elé tett mínusz jellel (pl. ", span({ style: "font-family: monospace;" }, "-CAM"), ")."),
          div({ style: "margin-top: 2px;" }, "• Reguláris kifejezés: ", span({ style: "font-family: monospace;" }, "/minta/i"), " formátumban.")
        )
      ),
      div({ style: "margin-top: auto;" },
        button({ class: "btn btn-primary", onclick: saveUserSettings, style: "width: 100%; display: flex; justify-content: center; gap: 0.5rem;" },
          Icons.save(),
          "Mentés"
        )
      )
    ),

    // Tab 4: Súgó & Gyorsbillentyűk
    div({ class: () => `tab-content ${activeTab.val === "help" ? "active" : ""}` },
      div({ class: "settings-section update-section", style: "margin-bottom: 0.75rem; padding: 0.75rem; border-radius: 8px; background: var(--card-bg, rgba(255,255,255,0.04)); border: 1px solid var(--border-color, rgba(255,255,255,0.1));" },
        div({ class: "flex items-center justify-between", style: "margin-bottom: 0.5rem;" },
          div({ class: "font-semibold flex items-center gap-2", style: "font-size: 0.85rem; color: var(--accent);" },
            Icons.refresh(),
            span("Verzió & Frissítések")
          ),
          span({ class: "text-xs font-semibold", style: "color: var(--text-muted);" }, `Telepítve: v${browser.runtime.getManifest().version}`)
        ),
        div({ class: "flex items-center gap-2", style: "margin-bottom: 0.5rem;" },
          button({
            class: "btn",
            style: "flex: 1; display: flex; justify-content: center; align-items: center; gap: 0.5rem; font-size: 0.8rem; padding: 0.4rem 0.75rem;",
            onclick: triggerCheckUpdate,
            disabled: () => isCheckingUpdate.val
          },
            Icons.refresh(),
            () => isCheckingUpdate.val ? "Ellenőrzés..." : "Frissítések keresése"
          ),
          a({
            class: "btn",
            style: "display: flex; align-items: center; gap: 0.35rem; font-size: 0.8rem; padding: 0.4rem 0.75rem; text-decoration: none;",
            href: "https://github.com/remal1/browser-extensions-releases/releases",
            target: "_blank",
            title: "Megnyitás a GitHubon"
          },
            Icons.external(),
            "GitHub"
          )
        ),
        () => updateCheckResult.val ? div({
          class: "text-xs",
          style: "color: var(--text-muted); margin-top: 0.25rem; line-height: 1.4;"
        }, updateCheckResult.val) : "",
        () => updateInfo.val?.hasUpdate ? div({
          class: "update-card",
          style: "margin-top: 0.5rem; padding: 0.6rem; border-radius: 6px; background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.35);"
        },
          div({ class: "flex items-center justify-between", style: "margin-bottom: 0.35rem;" },
            span({ style: "font-weight: 700; color: #10b981; font-size: 0.85rem;" }, `🎉 Új verzió érhető el: v${updateInfo.val.latestVersion}`),
            updateInfo.val.releaseDate ? span({ style: "font-size: 0.75rem; color: var(--text-muted);" }, updateInfo.val.releaseDate) : ""
          ),
          updateInfo.val.changelog ? div({
            style: "font-size: 0.75rem; color: var(--text-main); margin-bottom: 0.5rem; white-space: pre-line; line-height: 1.45;"
          }, updateInfo.val.changelog) : "",
          div({ class: "flex gap-2" },
            updateInfo.val.downloads?.chrome ? a({
              class: "btn btn-primary",
              style: "flex: 1; font-size: 0.75rem; padding: 0.35rem; text-align: center; text-decoration: none;",
              href: updateInfo.val.downloads.chrome,
              target: "_blank"
            }, "Chrome Letöltés (.zip)") : "",
            updateInfo.val.downloads?.firefox ? a({
              class: "btn btn-primary",
              style: "flex: 1; font-size: 0.75rem; padding: 0.35rem; text-align: center; text-decoration: none;",
              href: updateInfo.val.downloads.firefox,
              target: "_blank"
            }, "Firefox Letöltés (.xpi)") : ""
          )
        ) : ""
      ),
      div({ class: "help-section", style: "margin-bottom: 0.75rem;" },
        div({ class: "font-semibold flex items-center gap-2", style: "font-size: 0.85rem; margin-bottom: 0.5rem; color: var(--accent);" },
          Icons.keyboard(),
          span("Gyorsbillentyűk")
        ),
        div({ class: "flex flex-col gap-1.5 text-xs", style: "color: var(--text-main);" },
          div({ class: "flex items-center justify-between" },
            span("Lépkedés a listában"),
            div({ class: "flex gap-1" }, kbd("↑"), kbd("↓"))
          ),
          div({ class: "flex items-center justify-between" },
            span("Megnyitás az nCore-on"),
            kbd("Enter")
          ),
          div({ class: "flex items-center justify-between" },
            span("Részletek lenyitása"),
            kbd("Space")
          ),
          div({ class: "flex items-center justify-between" },
            span("Letöltés indítása"),
            kbd("D")
          ),
          div({ class: "flex items-center justify-between" },
            span("Könyvjelző ki/be"),
            kbd("B")
          ),
          div({ class: "flex items-center justify-between" },
            span("Cím és link másolása"),
            kbd("C")
          ),
          div({ class: "flex items-center justify-between" },
            span("Ugrás a tetejére / aljára"),
            div({ class: "flex gap-1" }, kbd("Home"), kbd("End"))
          ),
          div({ class: "flex items-center justify-between" },
            span("Gyorslapozás fel / le"),
            div({ class: "flex gap-1" }, kbd("PgUp"), kbd("PgDn"))
          ),
          div({ class: "flex items-center justify-between" },
            span("Keresőmező fókusz"),
            kbd("/")
          ),
          div({ class: "flex items-center justify-between" },
            span("Keresés törlése / bezárás"),
            kbd("Esc")
          ),
          div({ class: "flex items-center justify-between" },
            span("Súgó ablak megnyitása"),
            div({ class: "flex gap-1" }, kbd("?"), kbd("F1"))
          )
        )
      ),

      div({ class: "help-section", style: "margin-bottom: 0.75rem;" },
        div({ class: "font-semibold flex items-center gap-2", style: "font-size: 0.85rem; margin-bottom: 0.5rem; color: var(--accent);" },
          Icons.info(),
          span("Funkciók és tippek")
        ),
        div({ class: "flex flex-col gap-2 text-xs", style: "color: var(--text-muted); line-height: 1.45;" },
          p({ style: "margin: 0;" },
            span({ class: "font-semibold", style: "color: var(--text-main);" }, "🌐 Élő nCore keresés: "),
            "A keresőmezőbe írt szöveg után nyomj ", kbd("Enter"), "-t vagy kattints a földgömb gombra a teljes adatbázis lekérdezéséhez."
          ),
          p({ style: "margin: 0;" },
            span({ class: "font-semibold", style: "color: var(--text-main);" }, "➖ Kizárás a keresésből: "),
            "Használj mínusz jelet a kizárni kívánt kifejezések elé (pl. ", span({ style: "font-family: monospace; color: var(--text-main);" }, "Matrix -1080p"), ")."
          ),
          p({ style: "margin: 0;" },
            span({ class: "font-semibold", style: "color: var(--text-main);" }, "👁️ Gyors előnézet: "),
            "Vidd a kurzort a szem ikonra a borítókép és összefoglaló azonnali megjelenítéséhez."
          ),
          p({ style: "margin: 0;" },
            span({ class: "font-semibold", style: "color: var(--text-main);" }, "🖱️ Megnyitás háttérlapon: "),
            "Középső kattintással (görgőklikk) vagy ", kbd("Ctrl"), " + kattintással a torrent közvetlenül háttérlapon nyílik meg."
          ),
          p({ style: "margin: 0;" },
            span({ class: "font-semibold", style: "color: var(--text-main);" }, "⚡ Ugrás az új elemre: "),
            "A bővítmény automatikusan a még olvasatlan legidősebb torrenthez görgeti a listát, még akkor is, ha az összes elem új."
          )
        )
      ),

      div({ style: "margin-top: auto; padding-top: 0.5rem;" },
        button({
          class: "btn",
          style: "width: 100%; display: flex; justify-content: center; gap: 0.5rem;",
          onclick: () => document.getElementById("setting")?.classList.remove("is-active")
        },
          Icons.close(),
          "Bezárás"
        )
      )
    )
  );
}
