/**
 * ui/footer.js - Footer Controls, Filter Dropdown & Settings Modal Mount
 */

function addControls() {
  const { button, div, span, input, label } = van.tags;

  const SortButton = (lbl, field) => {
    return button({
      class: "btn flex items-center gap-1",
      onclick: () => handleSort(field),
      title: `Rendezés: ${lbl}`
    },
      lbl,
      () => sortState.val.field === field
        ? (sortState.val.asc ? Icons.sortAsc() : Icons.sortDesc())
        : span({ style: "width: 18px; display: inline-block" })
    );
  };

  const generateBtns = () => {
    return div({ class: "footer-bar flex items-center justify-between" },
      div({ class: "flex items-center gap-4", style: "flex: 1; margin-right: 1rem;" },
        div({ class: "flex items-center gap-1" },
          SortButton("Név", "name"),
          SortButton("Feltöltés", "date")
        ),
        div({ class: "input-group", style: "flex: 1;" },
          input({
            class: "input",
            id: "torr-search",
            style: "width: 100%;",
            placeholder: () => searchMode.val === 'api' ? `Élő nCore keresés: "${apiQuery.val}"` : "Keresés (pl. Matrix -1080p)",
            title: "Tipp: Használj '-kifejezés'-t a kizáráshoz. Nyomj Entert az azonnali kereséshez.",
            onkeyup: search
          }),
          button({ class: "btn", onclick: searchClear, title: "Keresés törlése" }, Icons.close()),
          button({
            class: () => `btn ${searchMode.val === 'api' ? 'active btn-primary' : ''}`,
            onclick: () => {
              const query = document.getElementById("torr-search")?.value;
              if (searchMode.val === 'api') {
                exitApiSearch();
              } else {
                executeApiSearch(query);
              }
            },
            title: () => searchMode.val === 'api' ? "Kilépés az élő keresésből és vissza a friss listához" : "Keresés az nCore teljes adatbázisában (Élő API)"
          },
            () => searchMode.val === 'api' ? Icons.close() : Icons.globe(),
            () => searchMode.val === 'api' ? "Kilépés" : ""
          )
        )
      ),
      div({ class: "flex items-center gap-1.5" },
        button({
          class: () => `btn btn-icon ${onlyNewFilter.val ? 'active' : ''}`,
          onclick: toggleOnlyNew,
          title: "Csak olvasatlan / új torrentek mutatása"
        },
          Icons.bolt()
        ),
        button({
          class: () => `btn btn-icon btn-star ${onlyBookmarksFilter.val ? 'is-bookmarked active' : ''}`,
          onclick: toggleOnlyBookmarks,
          title: "Csak könyvjelzők / megcsillagozott torrentek mutatása"
        },
          () => onlyBookmarksFilter.val ? Icons.starFilled() : Icons.starOutline()
        ),
        button({
          class: "btn btn-icon",
          onclick: markAllAsRead,
          title: "Összes megjelölése olvasottként"
        },
          Icons.checkAll()
        ),
        div({ class: "dropdown", id: "filter" },
          button({
            class: () => `btn btn-icon ${filtersEnabled.val && (currentFilters.length || minSeedersFilter.val || minSizeMbFilter.val) ? 'active' : ''}`,
            id: "filter-btn",
            onclick: dropdownToggle,
            title: "Szűrők beállítása (kategóriák, seeder, méret)"
          },
            () => filtersEnabled.val ? Icons.filter() : Icons.filterOff()
          ),
          div({
            class: "dropdown-menu",
            id: "filter-container",
            style: "width: 320px; display: flex; flex-direction: column; height: 500px;"
          },
            div({ class: "flex items-center justify-between", style: "margin-bottom: 0.75rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--glass-border); flex-shrink: 0;" },
              div({ class: "font-semibold flex items-center gap-2", style: "font-size: 0.9rem;" },
                Icons.filter(),
                span("Szűrők")
              ),
              div({ class: "flex items-center gap-2" },
                label({ class: "switch" },
                  input({
                    id: "master-filter-toggle",
                    type: "checkbox",
                    checked: () => filtersEnabled.val,
                    onchange: () => toggleFilters()
                  }),
                  span({ class: "slider" })
                ),
                label({ class: "form-label", style: "margin-bottom: 0; font-size: 0.75rem; cursor: pointer;", for: "master-filter-toggle" },
                  () => filtersEnabled.val ? "Bekapcsolva" : "Kikapcsolva"
                )
              )
            ),
            div({ class: "filter-scroll-content" },
              div({ id: "filters" }),
              div({ class: "form-group", style: "margin-top: 0.5rem; padding-top: 0.5rem; border-top: 1px solid var(--glass-border); flex-shrink: 0;" },
                label({ class: "form-label", style: "font-size: 0.8rem; font-weight: 600;" }, "Gyorsszűrők"),
                div({ class: "flex gap-2" },
                  div({ class: "flex-1" },
                    label({ class: "form-label", style: "font-size: 0.72rem;" }, "Min. Seeder"),
                    input({
                      class: "input",
                      type: "number",
                      min: "0",
                      placeholder: "0 (nincs)",
                      value: () => minSeedersFilter.val || "",
                      oninput: e => {
                        minSeedersFilter.val = Math.max(0, parseInt(e.target.value, 10) || 0);
                        applyFilters(currentFilters, document.getElementById("torr-search")?.value);
                      }
                    })
                  ),
                  div({ class: "flex-1" },
                    label({ class: "form-label", style: "font-size: 0.72rem;" }, "Min. Méret (MB)"),
                    input({
                      class: "input",
                      type: "number",
                      min: "0",
                      placeholder: "pl. 1024",
                      value: () => minSizeMbFilter.val || "",
                      oninput: e => {
                        minSizeMbFilter.val = Math.max(0, parseInt(e.target.value, 10) || 0);
                        applyFilters(currentFilters, document.getElementById("torr-search")?.value);
                      }
                    })
                  )
                )
              )
            )
          )
        ),
        div({ class: "dropdown", id: "setting" },
          button({ class: "btn btn-icon", id: "setting-btn", onclick: dropdownToggle, title: "Beállítások" },
            Icons.gear()
          ),
          renderSettingsModal()
        )
      )
    );
  };

  van.add(document.querySelector("#footer"), generateBtns());
  addFilter();
}
