/**
 * ui/torrent-list.js - Torrent List, Virtual Container, Empty States & Floating Hover Preview
 */

function initList() {
  const { a, button, div, span, img } = van.tags;

  const generateError = () => {
    return div({
      class: "msg-danger",
      style: () => errorMessage.val ? "display: flex;" : "display: none;"
    },
      div({ style: "color: #f87171; flex-shrink: 0; margin-top: 1px; display: flex; align-items: center;" }, Icons.alert()),
      div({ class: "msg-danger-content", style: "flex: 1;" },
        div({ class: "msg-danger-title" }, "Hiba"),
        div(() => errorMessage.val),
        () => (errorMessage.val && (errorMessage.val.includes("Lejárt a munkamenet") || errorMessage.val.includes("bejelentkezve")))
          ? button({
              class: "btn btn-primary btn-sm",
              style: "margin-top: 0.5rem; display: inline-flex; align-items: center; gap: 0.35rem; font-size: 0.8rem; padding: 0.25rem 0.6rem;",
              onclick: (e) => {
                e.preventDefault();
                browser.tabs.create({ url: "https://ncore.pro/login.php" });
              }
            },
            Icons.external ? Icons.external() : Icons.bolt(),
            "Bejelentkezés az nCore-ra"
          )
          : "",
        () => isCached.val && torrentCache && torrentCache.length
          ? div({
              style: "margin-top: 0.45rem; font-size: 0.75rem; color: #fca5a5; opacity: 0.9; display: flex; align-items: center; gap: 0.35rem;"
            },
            Icons.database(),
            "A legutóbb sikeresen letöltött lista látható a gyorsítótárból."
          )
          : ""
      ),
      button({
        class: "msg-danger-close",
        onclick: (e) => {
          e.preventDefault();
          e.stopPropagation();
          errorMessage.val = "";
        },
        title: "Bezárás"
      }, Icons.close())
    );
  };

  const generateList = () => {
    return vanX.list(
      () => div({
        class: "flex flex-col",
        id: "torrent-items-container"
      }),
      items,
      ({ val: v }, index) => renderTorrentItem(v, index)
    );
  };

  const generateEmptyState = () => {
    return div({
      class: "empty-state-container",
      style: () => (listLength.val === 0 && !errorMessage.val) ? "display: flex;" : "display: none;"
    },
      () => {
        const reason = emptyStateReason.val;
        let icon = Icons.search();
        let title = "Nincs találat";
        let desc = "Nem található a keresési vagy szűrési feltételeknek megfelelő torrent.";
        let btnText = "Keresés törlése";
        let btnIcon = Icons.close();
        let btnAction = () => {
          searchClear();
          if (!filtersEnabled.val) toggleFilters();
        };

        if (reason.type === 'only_new') {
          icon = Icons.bolt();
          title = "Nincs új vagy olvasatlan torrent";
          desc = "Minden torrentet láttál már a listában, jelenleg nincs újabb feltöltés.";
          btnText = "Összes torrent megjelenítése";
          btnIcon = Icons.refresh();
          btnAction = () => toggleOnlyNew();
        } else if (reason.type === 'only_bookmarks') {
          icon = Icons.starOutline();
          title = "Nincsenek megcsillagozott torrentek";
          desc = "Még nem vettél fel egyetlen torrentet sem a könyvjelzők közé. Használd a csillag ikont bármelyik torrentnél!";
          btnText = "Összes torrent megjelenítése";
          btnIcon = Icons.refresh();
          btnAction = () => toggleOnlyBookmarks();
        } else if (reason.type === 'search') {
          icon = Icons.search();
          title = "Nincs helyi találat";
          desc = `Nem található torrent a friss listában erre: "${reason.query}"`;
          btnText = `Keresés az nCore teljes adatbázisában: "${reason.query}"`;
          btnIcon = Icons.globe();
          btnAction = () => executeApiSearch(reason.query);
        } else if (reason.type === 'category_filter') {
          icon = Icons.filter();
          title = "Nincs a szűrőknek megfelelő torrent";
          desc = "A beállított kategória szűrők alapján minden torrent el lett rejtve.";
          btnText = "Kategória szűrők kikapcsolása";
          btnIcon = Icons.filterOff();
          btnAction = () => toggleFilters();
        } else if (reason.type === 'no_data') {
          icon = Icons.database();
          title = "Nincsenek torrentek";
          desc = "A lista jelenleg üres, nem érkezett adat az nCore-tól.";
          btnText = "Frissítés most";
          btnIcon = Icons.refresh();
          btnAction = () => updateTorrentsList(true);
        }

        return div({ class: "flex flex-col items-center" },
          div({ class: "empty-state-icon" }, icon),
          div({ class: "empty-state-title" }, title),
          div({ class: "empty-state-desc" }, desc),
          button({
            class: "btn btn-primary",
            style: "margin-top: 1.25rem; display: inline-flex; align-items: center; gap: 0.5rem;",
            onclick: (e) => {
              e.preventDefault();
              btnAction();
            }
          },
            btnIcon,
            btnText
          )
        );
      }
    );
  };

  const generateLiveBanner = () => {
    return div({
      class: "live-search-banner",
      style: () => searchMode.val === "api" ? "display: flex;" : "display: none;"
    },
      div({ class: "flex items-center gap-2" },
        Icons.globe(),
        span(() => `Élő nCore keresési találatok: "${apiQuery.val}" (${apiTotalResults.val} találat)`)
      ),
      button({
        class: "btn btn-sm btn-ghost",
        onclick: exitApiSearch,
        style: "padding: 0.15rem 0.5rem; font-size: 0.72rem;"
      }, "Kilépés az élő keresésből")
    );
  };

  const generatePagination = () => {
    return div({
      class: "pagination-bar",
      style: () => searchMode.val === "api" ? "display: flex;" : "display: none;"
    },
      button({
        class: "btn btn-sm",
        disabled: () => apiCurrentPage.val <= 1,
        onclick: (e) => {
          e.preventDefault();
          executeApiSearch(apiQuery.val, apiCurrentPage.val - 1);
        }
      }, "◀ Előző oldal"),
      span({ class: "text-xs font-semibold" },
        () => `Oldal: ${apiCurrentPage.val} / ${Math.max(1, Math.ceil(apiTotalResults.val / 50))} (${apiTotalResults.val} db)`
      ),
      button({
        class: "btn btn-sm",
        disabled: () => apiCurrentPage.val >= Math.ceil(apiTotalResults.val / 50),
        onclick: (e) => {
          e.preventDefault();
          executeApiSearch(apiQuery.val, apiCurrentPage.val + 1);
        }
      }, "Következő oldal ▶"),
      button({
        class: "btn btn-sm btn-ghost",
        onclick: exitApiSearch
      }, Icons.close(), " Bezárás")
    );
  };

  const generatePermissionBanner = () => {
    return div({
      class: "permission-banner",
      style: () => needsPermission.val ? "display: flex;" : "display: none;"
    },
      div({ class: "permission-banner-icon" }, Icons.alert()),
      div({ class: "permission-banner-content" },
        div({ class: "permission-banner-title" }, "Engedély szükséges az nCore-hoz"),
        div({ class: "permission-banner-desc" }, "A telepített kiegészítőknél a Firefox jóváhagyást kér a webhely eléréséhez.")
      ),
      button({
        class: "btn btn-primary",
        style: "flex-shrink: 0;",
        onclick: async () => {
          try {
            const granted = await browser.permissions.request({
              origins: ["*://ncore.pro/*", "*://*.ncore.pro/*", "<all_urls>"]
            });
            if (granted) {
              needsPermission.val = false;
              showToast("Engedély megadva!", "success");
              await updateTorrentsList(true);
            }
          } catch (err) {
            showToast("Engedélykérés sikertelen: " + err.message, "error");
          }
        }
      }, "Engedélyezés")
    );
  };

  const generatePosterPreview = () => {
    return div({
      class: () => `poster-preview-tooltip ${hoverPreview.val.visible ? 'is-visible' : ''}`,
      style: () => `left: ${hoverPreview.val.x}px; top: ${hoverPreview.val.y}px;`
    },
      () => hoverPreview.val.loading
        ? div({ class: "preview-loading flex flex-col items-center justify-center gap-2", style: "height: 180px;" },
            Icons.refresh(),
            span({ class: "text-xs text-muted" }, "Borítókép betöltése...")
          )
        : (hoverPreview.val.poster
            ? div({ class: "preview-poster-wrapper", style: "position: relative; width: 100%;" },
                img({
                  class: "preview-poster-img",
                  src: hoverPreview.val.poster,
                  alt: "Poszter",
                  onerror: (e) => {
                    e.currentTarget.style.display = "none";
                    const fallback = e.currentTarget.parentElement?.querySelector(".preview-no-poster");
                    if (fallback) fallback.style.display = "flex";
                  }
                }),
                div({ class: "preview-no-poster flex flex-col items-center justify-center text-muted text-xs", style: "height: 120px; display: none;" },
                  Icons.image(),
                  span("A poszter nem tölthető be")
                )
              )
            : div({ class: "preview-no-poster flex flex-col items-center justify-center text-muted text-xs", style: "height: 120px;" },
                Icons.image(),
                span("Nincs elérhető poszter")
              )
          ),
      div({ class: "preview-meta flex flex-col gap-1", style: "padding: 0.2rem 0.1rem;" },
        div({ class: "flex items-center justify-between gap-2 text-xs" },
          () => hoverPreview.val.cat ? span({ class: "badge" }, hoverPreview.val.cat) : "",
          () => hoverPreview.val.imdbRating ? span({ class: "badge-imdb" }, `⭐ ${hoverPreview.val.imdbRating}`) : ""
        ),
        div({ class: "flex items-center justify-between gap-2 text-xs text-muted" },
          () => hoverPreview.val.size ? span(formatBytes(hoverPreview.val.size)) : "",
          () => hoverPreview.val.seeders != null ? span({ class: "text-success font-semibold" }, `S: ${hoverPreview.val.seeders}`) : ""
        )
      )
    );
  };

  const listContainer = document.querySelector("#torrent-list");
  van.add(listContainer, generateLiveBanner(), generateEmptyState(), generateList(), generatePagination());
  van.add(document.querySelector("#app-container"), generatePermissionBanner(), generateError(), generatePosterPreview());
}
