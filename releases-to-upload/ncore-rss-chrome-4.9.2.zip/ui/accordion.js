/**
 * ui/accordion.js - Accordion Details Panel Component
 */

function renderAccordion(v) {
  const { a, button, div, span, img } = van.tags;

  getDropTrigger(v.id).val;
  const dropState = torrentDropCache[v.id];
  if (!dropState || dropState.loading) {
    return div({ class: "accordion-panel" },
      div({ class: "flex items-center justify-center gap-2 text-muted text-xs", style: "padding: 1rem;" },
        Icons.refresh(),
        span("Részletek és mintaképek betöltése...")
      )
    );
  }
  if (dropState.error) {
    return div({ class: "accordion-panel" },
      div({ class: "flex items-center gap-2 text-danger text-xs", style: "padding: 1rem;" },
        Icons.alert(),
        span("Hiba: " + dropState.error)
      )
    );
  }

  const data = dropState.data || {};

  // Build stat pill items
  const stats = [];
  if (data.commentsCount) {
    stats.push(
      a({
        class: "stat-pill stat-link",
        href: `https://ncore.pro/torrents.php?action=details&id=${v.id}#comments`,
        target: "_blank",
        title: "Hozzászólások megnyitása az nCore-on"
      },
        Icons.messageSquare(),
        span(data.commentsCount)
      )
    );
  }
  if (data.filesCount) {
    stats.push(
      a({
        class: "stat-pill stat-link",
        href: `https://ncore.pro/ajax.php?action=files&id=${v.id}`,
        target: "_blank",
        title: "Fájllista megnyitása"
      },
        Icons.folder(),
        span(data.filesCount.includes("db") ? data.filesCount : `${data.filesCount} db fájl`)
      )
    );
  }
  if (data.uploadedAt) {
    stats.push(
      div({ class: "stat-pill", title: "Feltöltés ideje" },
        Icons.clock(),
        span(data.uploadedAt.slice(0, 16).replace(/-/g, '.'))
      )
    );
  }

  return div({ class: "accordion-panel", onclick: (e) => e.stopPropagation() },
    div({ class: "accordion-inner" },
      div({ class: "accordion-header-row" },
        data.poster
          ? div({ class: "accordion-poster-box" },
              img({ class: "accordion-poster", src: data.poster, alt: "Borító", referrerpolicy: "no-referrer" })
            )
          : "",
        div({ class: "accordion-meta" },
          data.tags && data.tags.length > 0
            ? div({ class: "accordion-tags" },
                data.tags.map(tag => span({ class: "tag-badge" }, "#" + tag))
              )
            : "",
          data.descSnippet
            ? div({ class: "accordion-specs" }, data.descSnippet)
            : div({ class: "text-muted text-xs italic" }, "Nincs elérhető leírás."),
          data.externalLinks && data.externalLinks.length > 0
            ? div({ class: "accordion-ext-links" },
                data.externalLinks.map(link =>
                  a({
                    class: `ext-link-badge ext-link-${link.type}`,
                    href: link.url,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    title: `${link.label} megnyitása: ${link.url}`,
                    onclick: (e) => e.stopPropagation()
                  },
                    link.type === 'youtube' && Icons.play ? Icons.play() : Icons.external(),
                    span(link.label)
                  )
                )
              )
            : "",
          div({ class: "accordion-footer-row" },
            stats.length > 0
              ? div({ class: "accordion-stats-strip" }, stats)
              : div({ class: "accordion-stats-strip" }),
            div({ class: "accordion-actions" },
              a({
                class: "accordion-btn",
                href: `https://ncore.pro/torrents.php?action=details&id=${v.id}`,
                target: "_blank"
              }, Icons.external(), span("Adatlap")),
              a({
                class: "accordion-btn",
                href: `https://ncore.pro/ajax.php?action=files&id=${v.id}`,
                target: "_blank"
              }, Icons.folder(), span("Fájllista")),
              a({
                class: "accordion-btn",
                href: `https://ncore.pro/ajax.php?action=nfo&id=${v.id}`,
                target: "_blank"
              }, Icons.fileText(), span("NFO")),
              button({
                class: "accordion-btn",
                onclick: (e) => handleCopy(e, v)
              }, Icons.copy(), span("Link másolása"))
            )
          )
        )
      ),
      data.screenshots && data.screenshots.length > 0
        ? div({ class: "accordion-gallery" },
            data.screenshots.map(s => {
              const fullUrl = typeof s === 'string' ? s : (s.full || s.thumb);
              const thumbUrl = typeof s === 'string' ? s : (s.thumb || s.full);

              let retryCount = 0;
              let imageEl;
              let wrapEl;

              const triggerRetry = (e) => {
                if (e) {
                  e.preventDefault();
                  e.stopPropagation();
                }
                if (!wrapEl || !imageEl) return;
                wrapEl.classList.remove('is-error');
                wrapEl.classList.remove('is-loaded');

                if (retryCount === 0 && fullUrl && fullUrl !== imageEl.src) {
                  retryCount++;
                  imageEl.src = fullUrl;
                  return;
                }

                retryCount++;
                const originalUrl = thumbUrl || fullUrl;
                const cacheBuster = (originalUrl.includes('?') ? '&' : '?') + 'retry=' + Date.now();
                imageEl.src = originalUrl + cacheBuster;
              };

              imageEl = img({
                class: "accordion-thumb",
                src: thumbUrl,
                loading: "eager",
                alt: "Mintakép",
                referrerpolicy: "no-referrer",
                onload: () => {
                  if (wrapEl) wrapEl.classList.add('is-loaded');
                },
                onerror: () => {
                  if (retryCount < 2) {
                    setTimeout(() => triggerRetry(), 350);
                  } else {
                    if (wrapEl) {
                      wrapEl.classList.remove('is-loaded');
                      wrapEl.classList.add('is-error');
                    }
                  }
                }
              });

              wrapEl = div({ class: "accordion-thumb-wrapper" },
                div({ class: "thumb-spinner" }, Icons.refresh()),
                div({
                  class: "thumb-error",
                  title: "Kattints az újrapróbáláshoz",
                  onclick: triggerRetry
                }, Icons.refresh(), span("Újrapróbálás")),
                a({
                  class: "accordion-thumb-link",
                  href: fullUrl,
                  target: "_blank",
                  title: "Kép megnyitása teljes méretben"
                }, imageEl)
              );

              if (imageEl.complete && imageEl.naturalWidth > 0) {
                wrapEl.classList.add('is-loaded');
              }

              return wrapEl;
            })
          )
        : ""
    )
  );
}
