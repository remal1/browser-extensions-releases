/**
 * state.js - Reactive State Management & Utility Helpers
 */

let savedData;
let items = vanX.reactive([]);
let currentSettings;
let lastOpened = van.state(0);
let lastOpenedId = van.state(0);
let lastUpdated = van.state(0);
let sortState = van.state({ field: 'date', asc: false });
let filtersEnabled = van.state(true);
let onlyNewFilter = van.state(false);
let onlyBookmarksFilter = van.state(false);
let focusedIndex = van.state(-1);
let listLength = van.state(0);
let errorMessage = van.state("");
let toastMessage = van.state("");
let toastType = van.state("success");
let toastTimer = null;
let testClientStatus = van.state("");
let testClientType = van.state("info");
let isCached = van.state(false);
let needsPermission = van.state(false);
let emptyStateReason = van.state({ type: "none", query: "" });
let torrentCache;
let updateIsRunning = false;
let currentFilters = [];
let bookmarks = van.state([]);
let searchMode = van.state("local");
let updateInfo = van.state({ hasUpdate: false, latestVersion: "", changelog: "" });
let isCheckingUpdate = van.state(false);
let updateCheckResult = van.state("");
let isApiSearching = van.state(false);
let apiQuery = van.state("");
let apiCurrentPage = van.state(1);
let apiTotalResults = van.state(0);
let expandedTorrentId = van.state(null);
let torrentDropCache = vanX.reactive({});
let minSeedersFilter = van.state(0);
let minSizeMbFilter = van.state(0);
let visited = [];
let hoverPreview = van.state({
  visible: false,
  id: null,
  poster: null,
  title: "",
  cat: "",
  imdbRating: null,
  size: null,
  seeders: null,
  x: 0,
  y: 0,
  loading: false
});
let dropUpdateTrigger = van.state(0);
let dropTriggers = {};
function getDropTrigger(id) {
  if (!dropTriggers[id]) dropTriggers[id] = van.state(0);
  return dropTriggers[id];
}
function notifyDropUpdate(id) {
  if (id && dropTriggers[id]) {
    dropTriggers[id].val++;
  }
  if (id && hoverPreview.val.id === id && hoverPreview.val.visible) {
    const cached = torrentDropCache[id];
    if (cached && !cached.loading) {
      hoverPreview.val = {
        ...hoverPreview.val,
        poster: cached.data?.poster || null,
        loading: false
      };
    }
  }
}
let activeSettingsTab = van.state("settings");
let clientTorrents = vanX.reactive({});
let torrentHashes = {};
let clientUpdateTrigger = van.state(0);
function notifyClientUpdate() {
  clientUpdateTrigger.val++;
}
function getClientTorrent(id) {
  clientUpdateTrigger.val;
  return clientTorrents[id] || null;
}

async function load(params = ["torrentList", "settings", "lastOpened", "lastUpdated", "lastOpenedId", "visited", "filters", "torrentHashes"]) {
  try {
    return await browser.storage.local.get(params);
  } catch (error) {
    console.error("Storage load error:", error);
  }
}

function toPlain(obj) {
  if (!obj) return obj;
  try {
    return JSON.parse(JSON.stringify(obj));
  } catch (_) {
    return obj;
  }
}

async function safeSendMessage(msg) {
  try {
    const plainMsg = toPlain(msg);
    return await browser.runtime.sendMessage(plainMsg);
  } catch (error) {
    console.error("[safeSendMessage] error:", error);
    throw error;
  }
}

async function save(obj) {
  try {
    const plainObj = toPlain(obj);
    await browser.storage.local.set(plainObj);
  } catch (error) {
    console.error("Storage save error:", error);
  }
}

function debounce(fn, ms) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

function showToast(msg, type = "success", duration = 2500) {
  toastMessage.val = msg;
  toastType.val = type;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toastMessage.val = "";
  }, duration);
}

function showError(msg) {
  errorMessage.val = msg;
}

function formatRelativeTime(timestamp) {
  if (!timestamp) return '';
  const now = Date.now();
  const diffSec = Math.floor((now - timestamp) / 1000);
  if (diffSec < 60) return 'épp most';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin} perce`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours} órája`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) {
    const date = new Date(timestamp);
    return `tegnap ${date.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' })}`;
  }
  if (diffDays < 7) return `${diffDays} napja`;
  const date = new Date(timestamp);
  return date.toLocaleDateString('hu-HU', { month: 'short', day: 'numeric' });
}

function formatBytes(bytes, decimals = 2) {
  if (!+bytes) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function formatEta(sec) {
  if (!sec || sec <= 0) return '';
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  const remM = m % 60;
  return `${h}h ${remM}m`;
}

function isTorrentPaused(state) {
  if (!state) return false;
  const s = String(state).toLowerCase();
  return s.startsWith('paused') || s.startsWith('stopped') || s.includes('pause') || s.includes('stop');
}

function enrichTorrents(list) {
  if (!Array.isArray(list)) return [];
  for (let i = 0; i < list.length; i++) {
    const item = list[i];
    if (item && !item._catDef) {
      item._catDef = resolveCategory(item.cat, item.title);
    }
  }
  return list;
}
