/**
 * actions.js - User Interactions, Torrent Actions, Background Communication, and Client Settings
 */

let lastClickTime = 0;
let lastClickLink = "";

async function handleTorrentClick(e, link) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  if (!link) return;

  const now = Date.now();
  if (link === lastClickLink && now - lastClickTime < 250) {
    return;
  }
  lastClickTime = now;
  lastClickLink = link;

  if (!visited.includes(link)) {
    visited.push(link);
    try {
      await save({ visited });
    } catch (error) {
      console.error("Save visited error:", error);
    }
  }

  const isBackground = e && (e.button === 1 || e.ctrlKey || e.metaKey);

  if (isBackground) {
    await browser.tabs.create({ url: link, active: false });
    showToast("Megnyitva új lapon a háttérben!");
    return;
  }

  let querying = [];
  try {
    querying = await browser.tabs.query({
      url: "*://*.ncore.pro/*",
      currentWindow: true
    });
  } catch (err) {
    console.warn("Tab query warning:", err);
  }

  if (currentSettings.showInNewTab || querying.length === 0) {
    await browser.tabs.create({ url: link, active: true });
    return;
  }

  const activeTab = querying.find(tab => tab.active);
  const targetTab = activeTab || querying[0];
  await browser.tabs.update(targetTab.id, { url: link, active: true });
}

const dropInFlight = {};

async function fetchTorrentDrop(id) {
  if (torrentDropCache[id] && !torrentDropCache[id].loading && (torrentDropCache[id].data || torrentDropCache[id].error)) {
    return torrentDropCache[id];
  }
  if (dropInFlight[id]) {
    return dropInFlight[id];
  }

  torrentDropCache[id] = { loading: true, data: null, error: null };
  notifyDropUpdate(id);

  dropInFlight[id] = safeSendMessage({ action: "getTorrentDrop", id })
    .then(resp => {
      if (resp?.error) {
        torrentDropCache[id] = { loading: false, data: null, error: resp.error };
      } else if (resp?.response) {
        torrentDropCache[id] = { loading: false, data: resp.response, error: null };
      } else {
        torrentDropCache[id] = { loading: false, data: null, error: "Nincs válasz a háttérfolyamattól." };
      }
      return torrentDropCache[id];
    })
    .catch(err => {
      torrentDropCache[id] = { loading: false, data: null, error: err?.message || "Hálózati hiba" };
      return torrentDropCache[id];
    })
    .finally(() => {
      delete dropInFlight[id];
      notifyDropUpdate(id);
    });

  return dropInFlight[id];
}

function showPosterPreview(e, item) {
  if (!item) return;
  const target = e.currentTarget;
  const rect = target.getBoundingClientRect();
  
  // Position to the left of the action buttons
  const width = 200;
  const x = Math.max(10, rect.left - width - 12);
  const y = Math.min(window.innerHeight - 320, Math.max(10, rect.top - 60));
  
  const catDef = item._catDef || resolveCategory(item.cat, item.title);
  const catLabel = catDef ? catDef.label : (item.cat || "");
  
  const cached = torrentDropCache[item.id];
  const isLoaded = Boolean(cached && !cached.loading && (cached.data || cached.error));
  const hasPoster = cached?.data?.poster;
  
  hoverPreview.val = {
    visible: true,
    id: item.id,
    poster: hasPoster || null,
    title: item.title,
    cat: catLabel,
    imdbRating: item.imdbRating,
    size: item.size,
    seeders: item.seeders,
    x,
    y,
    loading: !isLoaded
  };
  
  if (!isLoaded) {
    fetchTorrentDrop(item.id).then(result => {
      if (hoverPreview.val.id === item.id) {
        hoverPreview.val = {
          ...hoverPreview.val,
          poster: result?.data?.poster || null,
          loading: false
        };
      }
    });
  }
}

function hidePosterPreview() {
  hoverPreview.val = { ...hoverPreview.val, visible: false, id: null };
}

async function handleDownload(e, item) {
  e.preventDefault();
  e.stopPropagation();
  try {
    if (currentSettings?.client?.type && currentSettings.client.type !== 'browser') {
      try {
        await browser.permissions.request({ origins: ["<all_urls>"] });
      } catch (_) {}
    }
    showToast("Küldés a kliensbe...", "info", 2000);
    const sending = await safeSendMessage({
      action: "downloadTorrent",
      id: item.id,
      title: item.title,
      cat: item.cat,
      downloadUrl: item.downloadUrl
    });
    if (sending?.error) {
      showToast("Hiba: " + sending.error, "error", 4500);
    } else if (sending?.response?.message) {
      showToast(sending.response.message, "success", 3000);
      if (sending.response.hash) {
        torrentHashes[item.id] = sending.response.hash;
        clientTorrents[item.id] = {
          hash: sending.response.hash,
          name: item.title,
          progress: 0,
          state: currentSettings?.client?.startImmediately === false ? 'pausedDL' : 'downloading',
          dlspeed: 0,
          upspeed: 0,
          eta: 0,
          size: item.size || 0
        };
        await save({ torrentHashes });
        notifyClientUpdate();
      }
      if (currentSettings?.client?.type && currentSettings.client.type !== 'browser') {
        setTimeout(pollClientTorrents, 600);
      }
    }
  } catch (err) {
    showToast("Letöltési hiba: " + err.message, "error", 4500);
  }
}

async function handleClientToggle(e, item) {
  e.preventDefault();
  e.stopPropagation();
  const info = getClientTorrent(item.id);
  if (!info || !info.hash) {
    return handleDownload(e, item);
  }
  const paused = isTorrentPaused(info.state);
  const command = paused ? 'resume' : 'pause';
  // Optimistic UI state update
  info.state = paused ? (info.progress >= 1 ? 'uploading' : 'downloading') : (info.progress >= 1 ? 'pausedUP' : 'pausedDL');
  notifyClientUpdate();
  showToast(paused ? "Letöltés folytatása..." : "Letöltés szüneteltetése...", "info", 1500);
  try {
    const res = await safeSendMessage({
      action: "controlTorrentClient",
      client: currentSettings?.client,
      hash: info.hash,
      command
    });
    if (res?.error) {
      showToast("Hiba: " + res.error, "error", 3000);
    }
  } catch (err) {
    showToast("Vezérlési hiba: " + err.message, "error", 3000);
  } finally {
    setTimeout(pollClientTorrents, 600);
  }
}

let clientPollTimer = null;
let isPollingClient = false;

async function pollClientTorrents() {
  if (isPollingClient) return;
  if (!currentSettings?.client?.type || currentSettings.client.type === 'browser') return;
  if (currentSettings.client.showProgress === false) return;

  isPollingClient = true;
  try {
    const res = await safeSendMessage({
      action: "getClientTorrents",
      client: currentSettings?.client
    });

    if (res?.error) {
      console.warn("[pollClientTorrents] Kliens lekérdezési hiba:", res.error);
    }

    if (res?.response && Array.isArray(res.response)) {
      const clientList = res.response;
      const clientByHash = new Map();
      const clientByName = new Map();

      for (const ct of clientList) {
        if (ct.hash) clientByHash.set(ct.hash.toLowerCase(), ct);
        if (ct.name) clientByName.set(ct.name.trim().toLowerCase(), ct);
      }

      const torrentList = items.length ? items : (torrentCache || []);
      let hasNewHashes = false;
      let updatedAny = false;

      for (const item of torrentList) {
        if (!item || !item.id) continue;
        let matched = null;
        const savedHash = torrentHashes[item.id];
        if (savedHash) {
          matched = clientByHash.get(savedHash.toLowerCase());
        }
        if (!matched && item.title) {
          matched = clientByName.get(item.title.trim().toLowerCase());
          if (!matched) {
            const cleanTitle = item.title.toLowerCase().replace(/[^a-z0-9]/g, '');
            for (const ct of clientList) {
              const cleanCtName = (ct.name || '').toLowerCase().replace(/\.(mkv|avi|mp4|rar|zip|iso)$/i, '').replace(/[^a-z0-9]/g, '');
              if (cleanTitle && cleanCtName) {
                if (cleanCtName === cleanTitle) {
                  matched = ct;
                  break;
                }
                // High-confidence substring match: require length >= 6 and >= 70% coverage
                const minLen = Math.min(cleanTitle.length, cleanCtName.length);
                const maxLen = Math.max(cleanTitle.length, cleanCtName.length);
                if (minLen >= 6 && (cleanCtName.includes(cleanTitle) || cleanTitle.includes(cleanCtName)) && (minLen / maxLen >= 0.7)) {
                  matched = ct;
                  break;
                }
              }
            }
          }
        }

        if (matched) {
          if (!torrentHashes[item.id] && matched.hash) {
            torrentHashes[item.id] = matched.hash;
            hasNewHashes = true;
          }
          clientTorrents[item.id] = {
            hash: matched.hash,
            name: matched.name,
            progress: matched.progress,
            state: matched.state,
            dlspeed: matched.dlspeed,
            upspeed: matched.upspeed,
            eta: matched.eta,
            size: matched.size
          };
          updatedAny = true;
        }
      }

      if (hasNewHashes) {
        save({ torrentHashes });
      }
      if (updatedAny) {
        notifyClientUpdate();
      }
    }
  } catch (err) {
    console.warn("[pollClientTorrents] hiba:", err);
  } finally {
    isPollingClient = false;
  }
}

function startClientPolling() {
  stopClientPolling();
  if (!currentSettings?.client?.type || currentSettings.client.type === 'browser') return;
  if (currentSettings.client.showProgress === false) return;

  pollClientTorrents();
  const intervalSec = Math.max(1, parseInt(currentSettings?.client?.pollInterval || 2, 10));
  clientPollTimer = setInterval(pollClientTorrents, intervalSec * 1000);
}

function stopClientPolling() {
  if (clientPollTimer) {
    clearInterval(clientPollTimer);
    clientPollTimer = null;
  }
}

async function handleCopy(e, item) {
  e.preventDefault();
  e.stopPropagation();
  try {
    const passkey = currentSettings?.key;
    const url = item.downloadUrl || (passkey
      ? `https://ncore.pro/torrents.php?action=download&id=${item.id}&key=${passkey}`
      : item.link);
    await navigator.clipboard.writeText(url);
    showToast("Letöltő link másolva a vágólapra!", "success");
  } catch (err) {
    showToast("Másolás sikertelen: " + err.message, "error");
  }
}

async function toggleBookmark(e, item) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  const id = item.id;
  let currentList = Array.isArray(bookmarks.val) ? [...bookmarks.val] : [];
  const idx = currentList.indexOf(id);
  if (idx >= 0) {
    currentList.splice(idx, 1);
    showToast("Eltávolítva a könyvjelzőkből", "info", 1500);
  } else {
    currentList.push(id);
    showToast("Hozzáadva a könyvjelzőkhöz!", "success", 1500);
  }
  bookmarks.val = currentList;
  await save({ bookmarks: currentList });
  if (onlyBookmarksFilter.val) {
    applyFilters(currentFilters, document.getElementById("torr-search")?.value);
  }
}

function scrollAccordionIntoView(id) {
  if (!id) return;
  requestAnimationFrame(() => {
    setTimeout(() => {
      const container = document.querySelector("#torrent-list");
      const card = document.querySelector(`.torrent-card-container[data-id="${id}"]`);
      if (!container || !card) return;

      const containerRect = container.getBoundingClientRect();
      const cardRect = card.getBoundingClientRect();

      const headerEl = document.querySelector("#header");
      const footerEl = document.querySelector("#footer");
      const headerHeight = headerEl ? headerEl.offsetHeight : 50;
      const footerHeight = footerEl ? footerEl.offsetHeight : 60;

      const visibleTop = containerRect.top + headerHeight;
      const visibleBottom = containerRect.bottom - footerHeight;

      if (cardRect.bottom > visibleBottom) {
        const overflowBottom = cardRect.bottom - visibleBottom + 14;
        container.scrollBy({ top: overflowBottom, behavior: "smooth" });
      } else if (cardRect.top < visibleTop) {
        const overflowTop = cardRect.top - visibleTop - 10;
        container.scrollBy({ top: overflowTop, behavior: "smooth" });
      }
    }, 60);
  });
}

async function toggleAccordion(e, item) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }
  if (expandedTorrentId.val === item.id) {
    expandedTorrentId.val = null;
    return;
  }
  expandedTorrentId.val = item.id;
  scrollAccordionIntoView(item.id);
  await fetchTorrentDrop(item.id);
  scrollAccordionIntoView(item.id);
}

async function sendCmd(cmd = "update") {
  let sending;
  try {
    sending = await safeSendMessage({ action: cmd });
  } catch (error) {
    throw error;
  }
  if (sending?.error) {
    throw new Error(sending.error);
  }
  if (!sending?.response) {
    throw Error("Frissítés sikertelen: Nem érkezett válasz a háttérfolyamattól.");
  }
  return sending;
}

async function updateTorrentsList(forced = false) {
  if (updateIsRunning) {
    console.warn("updateTorrentsList->frissítés már fut");
    return;
  }
  updateIsRunning = true;
  try {
    let sending;
    try {
      sending = await sendCmd(forced ? "forcedUpdate" : "update");
    } catch (error) {
      const errMsg = error?.message || error?.toString() || String(error);
      showError(errMsg);
      return;
    }

    if (!sending || !("response" in sending) || !Array.isArray(sending.response?.torrentList) || !sending.response?.torrentList.length) {
      showError("Frissítés sikertelen: Nem érkeztek torrentek az nCore-tól.");
      return;
    }
    if (sending?.response?.lastUpdated) {
      const lu = sending.response.lastUpdated;
      lastUpdated.val = typeof lu === 'number' ? lu : new Date(lu).getTime();
    }
    errorMessage.val = "";
    isCached.val = false;
    torrentCache = enrichTorrents(Array.from(sending.response.torrentList));
    applyFilters(currentFilters, document.getElementById("torr-search")?.value);
    checkScrollToNew();
  } finally {
    updateIsRunning = false;
  }
}

function settingsToggle(_) {
  const setting = document.getElementById("setting");
  if (setting) setting.classList.toggle("is-active");
}

async function saveUserSettings() {
  const currentSettingsPlain = toPlain(currentSettings);
  await save({ settings: currentSettingsPlain });

  const urlParams = new URLSearchParams(window.location.search);
  const isSidebar = urlParams.get('view') === 'sidebar' || document.body.classList.contains('is-sidebar');

  if (currentSettingsPlain.displayMode === 'popup' && isSidebar) {
    showToast("Beállítások elmentve! Váltás felugró ablakra...", "success", 1200);
    settingsToggle();
    setTimeout(async () => {
      try {
        const sidePanel = globalThis['chrome'] ? globalThis['chrome']['side' + 'Panel'] : null;
        if (sidePanel && typeof sidePanel['close'] === 'function') {
          const win = await browser.windows?.getCurrent();
          if (win?.id) await sidePanel['close']({ windowId: win.id }).catch(() => window.close());
          else window.close();
        } else if (typeof browser !== "undefined" && browser.sidebarAction && typeof browser.sidebarAction.close === 'function') {
          await browser.sidebarAction.close().catch(() => window.close());
        } else {
          window.close();
        }
      } catch (_) {
        window.close();
      }
    }, 600);
    return;
  }

  showToast("Beállítások elmentve!", "success");
  settingsToggle();
  startClientPolling();
}

async function runTestClient() {
  try {
    await browser.permissions.request({ origins: ["<all_urls>"] });
  } catch (err) {
    console.warn("Permission request warning:", err);
  }

  testClientStatus.val = "Kapcsolódás a torrent klienshez...";
  testClientType.val = "loading";
  try {
    const clientData = currentSettings?.client || { type: 'browser' };
    const res = await safeSendMessage({
      action: "testClient",
      client: clientData
    });
    if (res?.error) {
      testClientStatus.val = "Hiba: " + res.error;
      testClientType.val = "error";
    } else if (res?.response?.message) {
      testClientStatus.val = res.response.message;
      testClientType.val = "success";
    }
  } catch (err) {
    testClientStatus.val = "Teszt hiba: " + err.message;
    testClientType.val = "error";
  }
}


async function triggerCheckUpdate() {
  if (isCheckingUpdate.val) return;
  isCheckingUpdate.val = true;
  updateCheckResult.val = "Frissítések ellenőrzése...";
  try {
    const res = await safeSendMessage({ action: "checkUpdate" });
    const info = res?.response;
    if (info) {
      updateInfo.val = info;
      if (info.hasUpdate) {
        updateCheckResult.val = `Új verzió érhető el: v${info.latestVersion}!`;
        showToast(`Új verzió érhető el: v${info.latestVersion}!`, "info", 2500);
      } else {
        updateCheckResult.val = "A legfrissebb verziót használod.";
        showToast("A legfrissebb verziót használod.", "success", 2000);
      }
    } else {
      updateCheckResult.val = "Nem sikerült ellenőrizni a frissítéseket.";
    }
  } catch (err) {
    updateCheckResult.val = "Hiba az ellenőrzés során: " + (err.message || String(err));
  } finally {
    isCheckingUpdate.val = false;
  }
}
